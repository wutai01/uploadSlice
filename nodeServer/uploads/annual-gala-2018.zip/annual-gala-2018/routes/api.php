<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'happy-new-year'], function () {

    // 奖品信息
    Route::get('/user/prizes', 'ApiController@prizesOnClient');

    // 中奖信息
    Route::get('/lottety/records', 'ApiController@lottetyRecords');

    // 发红包
    Route::get('/leader/redpack', 'ApiController@sendRedPackage');
});
