<?php

/*
|--------------------------------------------------------------------------
| 微年会大屏幕
|--------------------------------------------------------------------------
|
| 弹幕，红包
|
*/
Route::get('screen', 'HappyNewYearController@screen');


/*
|--------------------------------------------------------------------------
| 年会后台
|--------------------------------------------------------------------------
|
| 1.奖品信息录入
| 2.中奖人员录入
| 3.中奖信息查询
*/
Route::group(['middleware' => [
    'auth', 'web'
]], function () {

    // 添加中奖信息页面
    Route::get('/user-prize', 'HappyNewYearController@index');

    // 投屏展示奖品，奖品中奖人员
    Route::group(['prefix' => 'api/happy-new-year'], function () {
        Route::put('/screen/prize', 'ApiController@inputDrawPrize');
        Route::put('/screen/prize-user', 'ApiController@inputDrawPrizeUser');

        // 结束抽奖
        Route::put('/screen/prize/end', 'ApiController@endPrize');

        // 切换大屏幕
        Route::put('/screen/switch', 'ApiController@switchScreen');

        // 奖品信息
        Route::get('/prizes', 'ApiController@getPrizes');
    });

    // 禁言
    Route::get('user/{openid}/trap', 'HappyNewYearController@changeUserStatus');
});

Route::group(['prefix' => 'mobile'], function () {
    Route::get('/prizes-dev', 'HappyNewYearController@prizes');
    Route::get('/prize/users', 'HappyNewYearController@prizeUsers');
    Route::get('/send-redpack', 'HappyNewYearController@redpack');
});

Route::get('sync-prizes', 'HappyNewYearController@syscPrize'); // 同步奖品

Route::get('cache', function () {
    $request = app('request');
    $key = $request->get('key');

    /**
     * @var \App\Utils\BoxApi $boxApi
     */
    $boxApi = app('box_api');
    $user = $request->get('user');
    $token = $request->get('token');
    try {
        $boxApi->verifyToken($user . '@bianfeng.com', $token);
    } catch (\Exception $e) {
        return [
            'code' => $e->getCode(),
            'message' => $e->getMessage()
        ];
    }

    /**
     * @var $redis \Predis\Client
     */
    $redis = app('redis');

    // 清除缓存
    if ('clear' == $key) {
        $keys = $redis->keys('annual:*');
        return $redis->del($keys);
    } else {
        return $redis->get('annual:' . $key);
    }
});

/*
|--------------------------------------------------------------------------
| 微信模块
|--------------------------------------------------------------------------
|
| 接收微信消息事件推送
|
*/
//Route::get('/', 'WechatController@index');
Route::post('/', 'WechatController@wxMsg');
Route::group(['prefix' => 'wechat'], function() {
    Route::post('msg', 'WechatController@wxMsg');
});


/*
|--------------------------------------------------------------------------
| Box模块
|--------------------------------------------------------------------------
|
| Box路由验证，Box菜单获取
|
*/
Route::group(['middleware' => 'auth.only'], function() {
    Route::get('/auth/ticket', function() {
        //授权成功之后需要跳转到何处
        if(isset($_GET['redirect'])) {
            $info = parse_url($_GET['redirect']);
            $path = isset($info['path']) ? $info['path'] : '/';
            $query = isset($info['query']) ? '?' . $info['query'] : '';
            return redirect($path . $query);
        } else {
            return redirect('/');
        }
    });
});

Route::get('box-menu', function () {
    return app('config')->get('auth_menu');
});