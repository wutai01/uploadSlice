<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 10:11
 */

define('ROOT_PATH', __DIR__ . DIRECTORY_SEPARATOR);

require 'vendor/autoload.php';

$app = \App\Server::instance();
$app->run();