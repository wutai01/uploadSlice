<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 16:01
 */

namespace App\Action;

use App\Components\Action;
use App\Components\Event;

class Login extends Action
{
    protected $name = 'login';
    protected $broadcast = false;
    public function handler(Event $event)
    {
        list($this->connection, $data) = $event->getParameters();
        if ($data['password'] != '#98q1231$4') {
            $this->error();
            $this->connection->close();
        }
        $this->connection->trust();
        redis()->incr('annual:connection_num');
        $this->ok();
    }
}