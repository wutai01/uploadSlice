<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 16:02
 */

namespace App\Action;

use App\Components\Action;
use App\Components\Event;

class ScreenSwitch extends Action
{
    protected $name = 'screen.switch';
    public function handler(Event $event)
    {
        $data = $event->getParameters();
        $this->ok($data);
    }
}