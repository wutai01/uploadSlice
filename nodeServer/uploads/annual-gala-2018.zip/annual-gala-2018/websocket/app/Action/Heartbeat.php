<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/30
 * Time: 19:23
 */

namespace App\Action;

use App\Components\Action;
use App\Components\Event;

class Heartbeat extends Action
{
    protected $name = 'heartbeat';
    protected $broadcast = false;
    public function handler(Event $event)
    {
        list($this->connection, ) = $event->getParameters();
        $this->connection->heartbeat();
        $this->ok();
    }
}