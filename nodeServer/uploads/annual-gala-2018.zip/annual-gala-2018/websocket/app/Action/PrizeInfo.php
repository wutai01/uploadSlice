<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 16:03
 */

namespace App\Action;

use App\Components\Action;
use App\Components\Event;

class PrizeInfo extends Action
{
    protected $name = 'prize.info';
    public function handler(Event $event)
    {
        $data = $event->getParameters();
        $this->ok($data);
    }
}