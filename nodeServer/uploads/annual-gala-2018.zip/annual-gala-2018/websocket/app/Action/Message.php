<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 16:02
 */

namespace App\Action;

use App\Components\Action;
use App\Components\Event;
use App\Lib\Utils\Filter;

class Message extends Action
{
    protected $name = 'message';
    public function handler(Event $event)
    {
        $data = $event->getParameters();
         // TODO 敏感词过滤

        if (! isset($data['content']) || ! $data['content']) {
            return;
        }
        $data['content'] = Filter::replace($data['content']);
        $this->ok($data);
    }
}