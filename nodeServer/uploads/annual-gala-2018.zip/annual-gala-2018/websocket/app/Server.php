<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 10:33
 */

namespace App;

use App\Components\Bus;
use App\Components\Connection;
use App\Lib\Utils\Config;
use Symfony\Component\Dotenv\Dotenv;

class Server
{
    private static $instance;

    /**
     * @var Subscribe $redis
     */
    private $redis;

    /**
     * @var \swoole_websocket_server $server
     */
    private $server;
    private $config;
    private $connections = [];
    private $bus;

    private function __construct()
    {
        $this->init();
    }

    public static function instance()
    {
        if (self::$instance instanceof self) {
            return self::$instance;
        }
        self::$instance = new self();
        return self::$instance;
    }

    public function init()
    {
        $dotEnv = new Dotenv();
        $dotEnv->load(ROOT_PATH . '.env');
        Config::instance()->load(ROOT_PATH . 'config');
        $this->config = config('server');
        $this->bus = Bus::instance();
        $this->redis = redis();
        $this->redis->set('annual:connection_num', 0);
    }


    public function run()
    {
        $this->start();
    }

    public function start()
    {
        logger()->info(posix_getpid(), '开启服务器:' . $this->config['listen'] . ':' . $this->config['port']);
        $this->server = $server = new \swoole_websocket_server($this->config['listen'], (int)$this->config['port']);

        logger()->info(posix_getpid(), '配置服务器:' . json_encode($this->config['swoole'], JSON_UNESCAPED_UNICODE));
        $this->server->set($this->config['swoole']);
        $ports = array_map('intval', explode(',', $this->config['ports']));

        logger()->info(posix_getpid(), '监听多端口:' . $this->config['ports']);

        foreach ($ports as $port) {
            $this->server->addListener($this->config['listen'], (int)$port, SWOOLE_SOCK_TCP);
        }

        $this->bindEvent();

        $info = posix_getpwnam("gm");
        $uid = $info["uid"];
        $gid = $info['gid'];

        posix_setuid($uid);
        posix_setgid($gid);

        $this->server->start();
    }

    public function bindEvent()
    {
        $this->server->on('start', [$this, 'onServerStart']);
        $this->server->on('managerStart', [$this, 'onManagerStart']);
        $this->server->on('workerStart', [$this, 'onWorkerStart']);
        $this->server->on('connect', [$this, 'onConnect']);
        $this->server->on('task', [$this, 'onTask']);

        $this->server->on('shutdown', [$this, 'onServerShutdown']);
        $this->server->on('managerStop', [$this, 'onManagerStop']);
        $this->server->on('workerStop', [$this, 'onWorkerStop']);
        $this->server->on('close', [$this, 'onClose']);
        $this->server->on('workerError', [$this, 'onWorkerError']);
        $this->server->on('open', [$this, 'onOpen']);

//        $this->server->on('timer', [$this, 'onTimer']);
        $this->server->on('message', [$this, 'onMessage']);
        $this->server->on('finish', [$this, 'onFinish']);
//        $this->server->on('pipeMessage', [$this, 'onPipeMessage']);
    }

    public function broadcast($msg)
    {
        /**
         * @var Connection $connection
         */
        foreach ($this->connections as $fd => $connection) {
            if ($connection->isTrusted()) {
                $connection->send($msg);
            }
        }
    }

    /**
     * 握手回调
     *
     * @param $server
     * @param $request
     */
    public function onOpen($server, $request)
    {
        logger()->info(posix_getpid(), "Connection Open.");
    }

    /**
     * @param \swoole_server $server
     */
    public function onManagerStart(\swoole_server $server)
    {
        logger()->info(posix_getpid(), "Manager Start.");
    }

    /**
     * @param \swoole_server $server
     */
    public function onManagerStop(\swoole_server $server)
    {
        logger()->error(posix_getpid(), "Manager Stop.");
    }

    public function onServerStart()
    {
        logger()->info(posix_getpid(), "Server Start.");
    }

    public function onServerShutdown()
    {
        logger()->error(posix_getpid(), "Server Shutdown.");
    }

    /**
     * @param \swoole_server $server
     * @param int $workerId
     */
    public function onWorkerStart(\swoole_server $server, $workerId)
    {
        if ($workerId >= $server->setting['worker_num']) {
            logger()->info(posix_getpid(), "Task Worker {$workerId} Start.");
        } else {
            logger()->info(posix_getpid(), "Worker {$workerId} Start.");
        }

        if (! $server->taskworker) {
            $redis = new Subscribe();
            $redis->subscribe();
        }
    }


    /**
     * @param \swoole_server $server
     * @param int $workerId
     */
    public function onWorkerStop(\swoole_server $server, $workerId)
    {
        if ($workerId >= $server->setting['worker_num']) {
            logger()->info(posix_getpid(), "Task Worker {$workerId} Stop.");
        } else {
            logger()->info(posix_getpid(), "Worker {$workerId} Stop.");
        }
    }

    /**
     * @param \swoole_server $server
     * @param int $workerId
     * @param int $workerPid
     * @param int $exitCode
     */
    public function onWorkerError(\swoole_server $server, $workerId, $workerPid, $exitCode)
    {
        logger()->error(posix_getpid(), "worker {$workerId} exit. code: {$exitCode}.");
    }

    /**
     * @param \swoole_websocket_server $server
     * @param \swoole_websocket_frame $frame
     */
    public function onMessage(\swoole_websocket_server $server, \swoole_websocket_frame $frame)
    {
        if (!isset($this->connections[$frame->fd])) {
            $connection = new Connection($server, $frame->fd);
        } else {
            $connection = $this->connections[$frame->fd];
        }
        $this->bus->clientMsg($connection, $frame, $this);
    }

    /**
     * @param \swoole_websocket_server $server
     * @param int $fd
     * @param int $fromId
     * @return void
     */
    public function onClose(\swoole_websocket_server $server, $fd, $fromId)
    {
        if (!isset($this->connections[$fd])) {
            $connection = new Connection($server, $fd);
        } else {
            $connection = $this->connections[$fd];
        }

        logger()->trace(posix_getpid(), 'Connection Close:' . $connection);
        if ($connection->isTrusted()) {
            $this->redis->decr('annual:connection_num');
        }
        unset($this->connections[$fd]);
        unset($connection);
        unset($event);
    }

    /**
     * @param \swoole_websocket_server $server
     * @param int $fd
     * @param int $fromId
     * @return void
     */
    public function onConnect(\swoole_websocket_server $server, $fd, $fromId)
    {
        $connection = new Connection($server, $fd);
        logger()->trace(posix_getpid(), 'Connection Connect:' . $connection);
        $this->connections[$fd] = $connection;
//        $event = new ConnectionEvent('connect', [$connection], $server);
//        $this->dispatch($event);
//        unset($event);
    }

    /**
     * @param \swoole_server $server
     * @param int $interval
     */
    public function onTimer(\swoole_server $server, $interval)
    {
        #self::trace(posix_getpid(), count($server->connections));
    }

    /**
     * @param \swoole_server $server
     * @param int $taskId
     * @param int $fromId
     * @param mixed $data
     */
    public function onTask(\swoole_server $server, $taskId, $fromId, $data)
    {
        if (!is_array($data)) {
            logger()->error(posix_getpid(), 'WRONG TASK PACKET. DATA:' . json_encode($data, JSON_UNESCAPED_UNICODE));
            return;
        }

        logger()->trace(posix_getpid(), "Task Coming: {$taskId} From: {$fromId} Data: " . json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    /**
     * @param \swoole_server $server
     * @param int $taskId
     * @param string $data
     */
    public function onFinish(\swoole_server $server, $taskId, $data)
    {
        logger()->debug(posix_getpid(), "Task {$taskId} Finished.");
    }


}