<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 14:51
 */

namespace App\Components;

class Event
{
    protected $name;
    protected $parameters;
    protected $sender;

    public function getName()
    {
        return $this->name;
    }

    public function getParameters()
    {
        return $this->parameters;
    }

    public function getSender()
    {
        return $this->sender;
    }

    public function __construct($name, $parameters = [], $sender = null)
    {
        $this->name = $name;
        $this->parameters = $parameters;
        $this->sender = $sender;
    }
}