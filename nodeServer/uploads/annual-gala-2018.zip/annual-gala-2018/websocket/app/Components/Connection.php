<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 10:37
 */

namespace App\Components;

class Connection
{
    private $lastHeartbeat;

    public function __construct(\swoole_server $server, $fd)
    {
        $this->server = $server;
        $this->fd = $fd;
        $this->data = $server->connection_info($fd, null, true);
        $this->heartbeat();
        swoole_timer_tick(5000, function ($timerId) {
            if ((time() - $this->lastHeartbeat) > 5) {
                swoole_timer_clear($timerId);
                logger()->warn(posix_getpid(), '未检测到心跳，断开连接:' . $this->fd);
                $this->close();
            }
        });
    }

    protected $data;

    /**
     * @var \swoole_server
     */
    protected $server;

    protected $fd;
    protected $trusted = false;

    public function trust()
    {
        $this->trusted = true;
    }

    public function heartbeat()
    {
        $this->lastHeartbeat = time();
    }

    public function isTrusted()
    {
        return $this->trusted;
    }

    public function getFd()
    {
        return (int)$this->fd;
    }

    public function getFromId()
    {
        return (int)$this->data['from_id'];
    }

    public function getServerFd()
    {
        return (int)$this->data['server_fd'];
    }

    public function getRemotePort()
    {
        return (int)$this->data['remote_port'];
    }

    public function getServerPort()
    {
        return (int)$this->data['server_port'];
    }

    public function getRemoteIp()
    {
        return $this->data['remote_ip'];
    }

    public function getConnectTime()
    {
        return (int)$this->data['connect_time'];
    }

    public function getLastTime()
    {
        return (int)$this->data['last_time'];
    }

    private $_closed = false;

    public function setClosed($value)
    {
        $this->_closed = !!$value;
    }

    /**
     * @param $message
     * @param int $opCode
     * @param bool $finish
     * @throws \Exception
     * @return bool
     */
    public function send($message, $opCode = 1, $finish = true)
    {
        if ($this->_closed) {
            return false;
        }

        if (empty($message)) {
            return false;
        }

        if ($this->server instanceof \swoole_websocket_server) {
            return $this->server->push($this->fd, $message, $opCode, $finish);
        } else {
            throw new \Exception(get_class($this->server) . ' is not support this feature.');
        }
    }

    /**
     *
     */
    public function close()
    {
        $this->_closed = true;
        return $this->server->close($this->fd);
    }

    public function __toString()
    {
        return "[{$this->fd}:{$this->getServerPort()} {$this->getRemoteIp()}:{$this->getRemotePort()}]";
    }
}