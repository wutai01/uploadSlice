<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 15:26
 */

namespace App\Components;

use App\Components\Event;

class Bus
{
    private $actions;
    private static $instance;


    private function __construct()
    {
    }

    public static function instance()
    {
        if (self::$instance instanceof self) {
            return self::$instance;
        }
        self::$instance = new self();
        return self::$instance;
    }

    public function clientMsg($connection, $frame, $sender)
    {

        $data = json_decode($frame->data, true);
        if (! $data || !isset($data['action']) || ! isset($data['body'])) {
            logger()->warn(posix_getpid(), "[{$frame->fd}]错误的消息：" . $frame->data);
            unset($data);
            return;
        }

        switch ($data['action']) {
            case 'login':
                $event = new Event('login', [$connection, $data['body']], $sender);
                break;
            case 'heartbeat':
                $event = new Event('heartbeat', [$connection, []], $sender);
                break;
            default:
                logger()->warn(posix_getpid(), "[{$frame->fd}]错误的action：" . $frame->data);
                unset($data);
                return;
        }
        $this->dispatch($event);
    }

    public function redisMsg($topic, $data, $sender)
    {
        $topicArr = explode('.', $topic);
        $prefix = array_shift($topicArr);
        if ('annual' !== $prefix) {
            logger()->warn(posix_getpid(), '未处理的topic' . $topic);
            return;
        }
        $data = json_decode($data, true);
        if (! empty($data)) {
            $event = new Event(implode('.', $topicArr), $data, $sender);
            $this->dispatch($event);
        }
    }

    public function dispatch(Event $event)
    {
        $name = $event->getName();
        if (isset($this->actions[$name])) {
            /**
             * @var Action $action
             */
            $action = $this->actions[$name];
        } else {
            $className = 'App\\Action\\' . implode('', array_map('ucfirst', explode('.', $name)));
            if (class_exists($className)) {
                /**
                 * @var Action $action
                 */
                $action = new $className();
                $this->actions[$name] = $action;
            } else {
                logger()->warn(posix_getpid(), '未处理的消息类型' . $event->getName());
                return;
            }
        }
        $action->handler($event);
    }
}