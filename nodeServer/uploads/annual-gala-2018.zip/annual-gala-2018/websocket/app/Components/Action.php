<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 16:11
 */

namespace App\Components;

abstract class Action
{
    protected $name = '';
    protected $broadcast = true;
    /**
     * @var Connection $connection
     */
    protected $connection;
    abstract public function handler(Event $event);

    public function ok($data= [], $message = 'success')
    {
        $data = [
            'action' => $this->name,
            'code' => 0,
            'data' => $data,
            'message' => $message,
        ];
        $this->send($data);
    }

    public function error($message = 'error', $code = 1)
    {
        $data = [
            'action' => $this->name,
            'code' => 0,
            'data' => [],
            'message' => $message,
        ];
        $this->send($data);
    }

    public function send($data)
    {
        $message = json_encode($data);
        if ($this->broadcast) {
            $this->broadcast($message);
        } else {
            $this->connection->send($message);
        }
    }

    public function broadcast($message)
    {
        app()->broadcast($message);
    }
}