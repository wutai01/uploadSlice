<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 14:47
 */

namespace App;

use App\Components\Bus;

class Subscribe
{
    private $client;
    private $config;
    private $bus;
    private $topic;

    public function __construct()
    {
        $this->config = config('database.redis');
        $this->bus = Bus::instance();
        $this->topic = config('app.redis_topic');
    }

    public function onMessage(\swoole_redis $client, $result)
    {
        logger()->info(posix_getpid(), json_encode($result, JSON_UNESCAPED_UNICODE));
        if ('pmessage' === $result[0]) {
            $this->bus->redisMsg($result[2], $result[3], $this);
        }
    }

    public function onClose(\swoole_redis $client)
    {
        logger()->info(posix_getpid(), 'redis closed');
        $this->subscribe();
    }

    public function subscribe()
    {
        $this->client = new \swoole_redis;
        $this->client->on('message', [$this, 'onMessage']);
        $this->client->on('close', [$this, 'onClose']);
        $this->client->connect($this->config['host'], $this->config['port'], function (\swoole_redis $client, $result) {
            logger()->info(posix_getpid(), 'redis connected');
            $client->psubscribe($this->topic);
        });
    }
}