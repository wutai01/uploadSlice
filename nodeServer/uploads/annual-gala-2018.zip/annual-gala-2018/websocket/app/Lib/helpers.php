<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 10:04
 */

if (! function_exists('env')) {
    function env($key)
    {
        return getenv($key);
    }
}

if (! function_exists('config')) {
    function config($key)
    {
        return \App\Lib\Utils\Config::instance()->get($key);
    }
}

if (! function_exists('logger')) {
    function logger()
    {
        return \App\Lib\Utils\Log::instance();
    }
}

if (! function_exists('app')) {
    function app()
    {
        return \App\Server::instance();
    }
}

if (! function_exists('redis')) {
    function redis()
    {
        return \App\Lib\Utils\Redis::instance()->client();
    }
}