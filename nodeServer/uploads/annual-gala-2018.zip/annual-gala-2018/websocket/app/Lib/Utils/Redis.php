<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/29
 * Time: 13:41
 */

namespace App\Lib\Utils;

class Redis
{
    private $client;
    private static $instance;
    private $config;

    private function __construct()
    {
        $this->config = config('database.redis');
        $this->client = new \Redis();
        $this->client->connect($this->config['host'], $this->config['port']);
    }

    public static function instance()
    {
        if (self::$instance instanceof self) {
            return self::$instance;
        }
        self::$instance = new self();
        return self::$instance;
    }

    public function client()
    {
        return $this->client;
    }
}