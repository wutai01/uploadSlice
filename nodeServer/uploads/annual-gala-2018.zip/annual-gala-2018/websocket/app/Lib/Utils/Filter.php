<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/25
 * Time: 16:30
 */

namespace App\Lib\Utils;

class Filter
{
    const WORD_PATH = ROOT_PATH . 'res/badwords.txt';

    static $badWords = [];

    public static function replace($string, $to = '***')
    {
        if (empty(self::$badWords)) {
            $src = file_get_contents(self::WORD_PATH);
            $arr = explode('<!!@!!>', $src);
            $trans = [];
            foreach ($arr as $value) {
                if ('' == $value) {
                    continue;
                }
                $trans[$value] = $to;
            }
            self::$badWords = $trans;
        }
        return strtr($string, self::$badWords);
    }
}