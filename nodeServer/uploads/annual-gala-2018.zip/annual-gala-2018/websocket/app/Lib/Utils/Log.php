<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 10:33
 */

namespace App\Lib\Utils;

class Log
{
    private static $instance;
    private $logLevel;
    private $debug;

    const LOG_TYPE_TRACE = 1;
    const LOG_TYPE_DEBUG = 2;
    const LOG_TYPE_INFO  = 3;
    const LOG_TYPE_WARN  = 4;
    const LOG_TYPE_ERROR = 5;

    private function __construct()
    {
        $this->logLevel = env('LOG_LEVEL');
        $this->debug = (bool)env('APP_DEBUG');
    }

    public static function instance()
    {
        if (self::$instance instanceof self) {
            return self::$instance;
        }
        self::$instance = new self();
        return self::$instance;
    }

    /**
     * print console log
     *
     * @param int $pid
     * @param mixed $message
     * @param int $type
     * @param string $file
     * @param int $line
     * @return void
     */
    protected function printConsoleLog($pid, $message, $type = self::LOG_TYPE_TRACE, $file = '', $line = 0)
    {
        $types = ['', 'trace', 'debug', 'info', 'warn', 'error'];
        $type = strtoupper($types[$type]);

        if (!is_string($message)) {
            $message = json_encode($message);
        }

        $mem = sprintf('%.2fMB', memory_get_usage() / 1024 / 1024);

        $format = "[" . date('Y-m-d H:i:s.') . substr((microtime(1) * 10000), -4, 4) . "][%d][%s:%d({$mem})]%s: %s\n";
        $text = sprintf($format, $pid, $file, $line, $type, $message);

        if ($type === 'TRACE') {
            print Colors::render($text, 'green');
        } elseif ($type === 'DEBUG') {
            print Colors::render($text, 'blue');
        } elseif ($type === 'INFO') {
            print Colors::render($text, 'yellow');
        } elseif ($type === 'WARN') {
            print Colors::render($text, 'light_red');
        } else {
            print Colors::render($text, 'red');
        }
    }

    public function trace($pid, $message)
    {
        if (!$this->debug || $this->logLevel > self::LOG_TYPE_TRACE) {
            return;
        }

        $trace = debug_backtrace();
        $caller = $trace[0];
        $file = pathinfo($caller['file'], PATHINFO_BASENAME);
        $line = $caller['line'];
        $this->printConsoleLog($pid, $message, self::LOG_TYPE_TRACE, $file, $line);
    }

    public function info($pid, $message)
    {
        if (!$this->debug || $this->logLevel > self::LOG_TYPE_INFO) {
            return;
        }

        $trace = debug_backtrace();
        $caller = $trace[0];
        $file = pathinfo($caller['file'], PATHINFO_BASENAME);
        $line = $caller['line'];
        $this->printConsoleLog($pid, $message, self::LOG_TYPE_INFO, $file, $line);
    }

    public function debug($pid, $message)
    {
        if (!$this->debug || $this->logLevel > self::LOG_TYPE_DEBUG) {
            return;
        }

        $trace = debug_backtrace();
        $caller = $trace[0];
        $file = pathinfo($caller['file'], PATHINFO_BASENAME);
        $line = $caller['line'];
        $this->printConsoleLog($pid, $message, self::LOG_TYPE_DEBUG, $file, $line);
    }

    public function warn($pid, $message)
    {

        if (!$this->debug || $this->logLevel > self::LOG_TYPE_WARN) {
            return;
        }

        $trace = debug_backtrace();
        $caller = $trace[0];
        $file = pathinfo($caller['file'], PATHINFO_BASENAME);
        $line = $caller['line'];
        $this->printConsoleLog($pid, $message, self::LOG_TYPE_WARN, $file, $line);
    }

    public function error($pid, $message)
    {
        if (!$this->debug || $this->logLevel > self::LOG_TYPE_ERROR) {
            return;
        }

        $trace = debug_backtrace();
        $caller = $trace[0];
        $file = pathinfo($caller['file'], PATHINFO_BASENAME);
        $line = $caller['line'];
        $this->printConsoleLog($pid, $message, self::LOG_TYPE_ERROR, $file, $line);
    }
}