<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 10:55
 */

namespace App\Lib\Utils;

class Config
{

    private static $instance;

    private $config = [];

    private function __construct()
    {

    }

    public static function instance()
    {
        if (self::$instance instanceof self) {
            return self::$instance;
        }
        self::$instance = new self();
        return self::$instance;
    }

    public function get($string)
    {
        $keys = explode('.', $string);
        $res = $this->config;
        while ($key = current($keys)) {
            if (isset($res[$key])) {
                $res = $res[$key];
            } else {
                return null;
            }
            next($keys);
        }
        return $res;
    }

    public function set()
    {

    }

    public function load($dir)
    {
        $files = scandir($dir);
        $config = [];
        foreach ($files as $file) {
            if (! preg_match('/.php$/', $file)) {
                continue;
            }
            $key = explode('.', $file)[0];
            $config[$key] = require_once $dir . DIRECTORY_SEPARATOR . $file;
        }
        $this->config = array_merge($this->config, $config);
    }
}