<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 15:45
 */

return [
    'App\Events\RegisterEvent' => [
        'App\Listeners\RegisterListener',
    ],
    'App\Events\TaskDoneEvent' => [
        'App\Listeners\TaskDoneListener',
    ],
];