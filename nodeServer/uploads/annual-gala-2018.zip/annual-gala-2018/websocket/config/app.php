<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 11:25
 */

return [
    'log_path' => ROOT_PATH . 'storage/logs',
    'redis_topic' => 'annual.*',
];