<?php
/**
 * Created by PhpStorm.
 * User: maoxiaoying
 * Date: 2018/1/24
 * Time: 14:21
 */

return [
    'listen'    => '0.0.0.0',
    'port'      => env('SERVER_PORT'),
    'ports'     => env('SERVER_PORTS'),
    // swoole配置
    'swoole'    => [
        'reactor_num'              => 1,        // 线程数为cpu核数的2倍
        'worker_num'               => 1,        // worker进程数
        'backlog'                  => 256,      // 等待accept的连接
        'max_request'              => 0,        // 不希望进程自动退出
        'daemonize'                => 0,        // 守护进程化
        'dispatch_mode'            => 4,        // IP分配
        'max_conn'                 => 1024,     // 最大允许的连接数
        'log_file'                 => ROOT_PATH . '../storage/logs/swoole.log',
        'open_length_check'        => 1,        // 确保收到一个完整的数据包
        'open_cpu_affinity'        => 1,        // reactor线程和worker进程绑定到固定的一个核上
        'task_worker_num'          => 0,        // 启动任务
//        'heartbeat_check_interval' => 5,        // 启用心跳检测
//        'heartbeat_idle_time'      => 60*10*10,       // 毫秒
    ],
];