'use strict';

/* ==========================================================
 * v20180124
 * ==========================================================
 * Copyright huhuiling
 *
 * 发口令红包
 * ========================================================== */

(function () {
  var oConfig = window.oPageConfig;

  var ui = {
    $btnSend: $('.js-btn-send'),
    $name: $('.j-send-name'),
    $token: $('.js-token')
  };
  var oPage = {
    init: function init() {
      this.view();
      this.listen();
    },
    view: function view() {
      var self = this;
    },
    listen: function listen() {
      var self = this;
      var param = {
        leader: '',
        token: ''
      };
      ui.$btnSend.on('click', function () {
        param = {
          leader: ui.$name.val(),
          token: ui.$token.val()
        };
        $.ajax({
          url: oConfig.oUrl.sendRedpacket,
          data: param,
          type: 'GET',
          dataType: 'json'
        }).done(function (msg) {
          if (0 == msg.code) {
            alert('红包发送成功！');
            ui.$name.val('');
            ui.$token.val('');
          } else {
            alert(msg.message);
          }
        });
      });
    }
  };
  oPage.init();
})($);