'use strict';

/* ==========================================================
 * v20180124
 * ==========================================================
 * Copyright huhuiling
 *
 * 
 * ========================================================== */

(function () {
  var oConfig = window.oPageConfig;

  var ui = {
    $btn: $('.js-game-button'),
    $searchNum: $('.js-search'),
    $numInput: $('.num-input'),
    $mask: $('.mask-wrap'),
    $lotteryInfo: $('.mask-cont'),
    $numberUl: $('.js-number-ul'),
    $searchBar: $('.search-bar-wrap'),
    $btnClear: $('.js-clear'),
    $btnCancel: $('.js-cancel')
  };
  var oPage = {
    init: function init() {
      this.view();
      this.listen();
    },
    view: function view() {
      var self = this;
    },
    listen: function listen() {
      var self = this;
      var keyNumber = '',
          bAutoSearch = true; //是否开启 input失去焦点自动搜索
      //清空input内容
      ui.$btnClear.on('click', function (e) {
        ui.$numInput.val('');
        keyNumber = '';
        bAutoSearch = false;
      });
      //输入框聚焦
      ui.$numInput.focus(function () {
        ui.$searchBar.addClass('inputting');
      });
      //输入框失焦自动搜索
      ui.$numInput.blur(function () {
        setTimeout(function () {
          ui.$searchBar.removeClass('inputting');
          keyNumber = ui.$numInput.val();
          if (keyNumber && bAutoSearch) {
            self.searchLotteryInfo(keyNumber);
          }
          bAutoSearch = true;
        }, 0);
      });
      //取消按钮
      ui.$btnCancel.on('click', function () {
        ui.$searchBar.removeClass('inputting');
        bAutoSearch = false;
      });
      //搜索按钮搜索
      ui.$searchNum.on('click', function (e) {
        keyNumber = ui.$numInput.val();
        if (keyNumber) {
          self.searchLotteryInfo(keyNumber);
        }
      });
      ui.$mask.on('click', function () {
        ui.$mask.hide();
      });
      //中奖详情页面 中奖编号居中显示
      if (ui.$numberUl.find('li').length <= 4) {
        ui.$numberUl.addClass('center');
      }
      if (ui.$numberUl.find('li').length == 0) {
        $('.no-data').css('display', 'block');
      }
    },
    //查询中奖信息
    searchLotteryInfo: function searchLotteryInfo(keyNumber) {
      ui.$mask.show();
      var lotteryInfoHtml = '';
      var param = {
        num: keyNumber
        //mock
        // var msg = {
        //   data:{
        //     prize:'幸运奖',
        //     gift:'200元京东卡200元京东卡'
        //   }
        //   // data:[]
        // }
        // lotteryInfoHtml =  msg.data.length == 0 ?'暂无'+keyNumber+'中奖信息...':'恭喜你，中了'+msg.data.prize+'！<br>奖品为' +msg.data.gift+'！'
        // ui.$lotteryInfo.html(lotteryInfoHtml)
        //end mock
      };
      $.ajax({
        url: oConfig.oUrl.getUserInfo,
        data: param,
        type: 'GET',
        dataType: 'json'
      }).done(function (msg) {
        if (0 == msg.code) {
          lotteryInfoHtml = msg.data.length == 0 ? '暂无' + keyNumber + '中奖信息...' : '恭喜你，中了' + msg.data[0].prize + '<br>奖品为' + msg.data[0].gift + '!';
          ui.$lotteryInfo.html(lotteryInfoHtml);
        }
      });
    }
  };
  oPage.init();
})($);