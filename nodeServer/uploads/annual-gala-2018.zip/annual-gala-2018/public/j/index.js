'use strict';

/* ==========================================================
* index.js v20180119
* ==========================================================
* by huhuiling
*
* 1、年会录入
* ========================================================== */
$(function () {
  var oConfig = window.oPageConfig;
  var ui = {};
  var numberList = []; //编号
  var prizeInfo = []; //奖项 奖品信息
  var storage = window.localStorage;
  var oPage = {
    init: function init() {
      this.view();
      this.listen();
      // this.typeChange()
    },
    view: function view() {
      var self = this;
    },
    listen: function listen() {
      var self = this;
      var tabIdx = 0,
          //当前tab页
      lotteryItem = '',
          //中奖单个li
      keyNumber = '',
          //输入的编号
      delItemIdx = '',
          //删除项的index
      param = {}; //中奖li 
      //init 初始渲染
      self.initPrizeInfo();
      //tab切换
      $('.tab-list .tab-item').on('click', function () {
        self.loadLotteryTable();
        $(this).addClass('active').siblings().removeClass('active');
        tabIdx = $(this).index();
        $('.tab-cont .tab-pane').eq(tabIdx).addClass('active').siblings().removeClass('active');
      });
      //监听select值变化
      $('.type-select').change(function (e) {
        prizeInfo.forEach(function (item) {
          if (item.id == e.target.value) {
            self.setPrizeNameList(item.gifts);
            return;
          }
        });
        self.clearNumberLi();
      });
      $('.name-select').change(function (e) {
        self.clearNumberLi();
      });
      //输入
      $('.number-input').on('keydown', function (e) {
        keyNumber = $('.number-input').val();
        lotteryItem = '<li><label>' + keyNumber + '</label><div class="btn-del"><i>x</i></div></li>';
        //回车录入
        if (e.keyCode == "13" && keyNumber != '') {
          var hasNumberIdx = $.inArray(keyNumber, numberList);
          if (hasNumberIdx != -1) {
            $('.lottery-list li').eq(hasNumberIdx).addClass('bgWarning');
            setTimeout(function () {
              $('.lottery-list li').eq(hasNumberIdx).removeClass('bgWarning');
            }, 1000);
          } else {
            $('.lottery-list ul').append(lotteryItem);
            numberList.push(keyNumber);
            storage.setItem('numberList', JSON.stringify(numberList));
            $('.number-input').val('');
          }
        }
      });
      //删除中奖名单
      $('.lottery-list').on('click', '.btn-del', function (e) {
        delItemIdx = $(this).closest('li').index();
        $('.lottery-list li').eq(delItemIdx).remove();
        numberList.splice(delItemIdx, 1);
      });
      //提交 奖品信息
      $('.btn-update-prize').on('click', function () {
        if (confirm('确认更新奖品信息？')) {
          param = {
            pid: $('.type-select').val(),
            gid: $('.name-select').val()
          };
          $.ajax({
            url: oConfig.oUrl.screenPrize,
            type: 'put',
            dataType: 'JSON',
            data: param
          }).done(function () {
            self.clearNumberLi();
          });
        }
      });
      //提交 中奖编号
      $('.btn-update-number').on('click', function () {
        if (confirm('确认更新中奖编号？')) {
          param = {
            pid: $('.type-select').val(),
            gid: $('.name-select').val(),
            numList: numberList
          };
          storage.setItem('numberList', JSON.stringify(numberList));
          $.ajax({
            url: oConfig.oUrl.screenLotteryNumber,
            type: 'put',
            dataType: 'JSON',
            data: param
          }).done(function () {
            self.clearNumberLi();
          });
        }
      });
      $('.btn-search').on('click', function () {
        self.loadLotteryTable();
      });
    }
    //奖品名称变化
    , setPrizeNameList: function setPrizeNameList(gifts) {
      var prizeNameHtml = '';
      gifts.forEach(function (i) {
        prizeNameHtml += '<option value =' + i.id + '>' + i.name + '</option>';
      });
      $('.name-select').empty().append(prizeNameHtml);
    }
    //初始渲染
    //中奖table 
    , loadLotteryTable: function loadLotteryTable() {
      var tableHtml = '';
      var param = {
        pid: $('.prize-list .type-select').val(),
        gid: $('.prize-list .name-select').val(),
        num: $('.prize-list .number').val()
      };
      //mock 
      // var tableData = [{
      //   "draw_num": 115,
      //   "prize": "幸运奖",
      //   "gift": "300元京东卡",
      //   "created_at": "2018-01-22 09:28:25"
      // }, {
      //   "draw_num": 105,
      //   "prize": "幸运奖",
      //   "gift": "200元京东卡",
      //   "created_at": "2018-01-22 09:28:25"
      // }];
      // tableData.forEach(function (item) {
      //   tableHtml = '<tr><td>' + item.prize + '</td><td>' + item.gift + '</td><td>' + item.draw_num + '</td><td>' + item.created_at + '</td></tr>';
      // });
      // $('table tbody').empty().append(tableHtml);
      //end mock

      $.ajax({
        url:oConfig.oUrl.lotteryRecords,
        type:'GET',
        dataType:'JSON',
        data:param
      })
      .done(function(msg){
        if(0 == msg.code){
          msg.data.forEach(function(item){
            tableHtml = '<tr><td>'+item.prize+'</td><td>'+item.gift+'</td><td>'+item.draw_num+'</td><td>'+item.created_at+'</td></tr>'
          })
          $('table tbody').empty().append(tableHtml)
        }
      })
    }
    //奖品信息
    ,
    initPrizeInfo: function initPrizeInfo() {
      var self = this;
      var numberListHtml = '',
          typeHtml = '',
          prizeType = [],
          prizeName = [];
      if (storage.getItem('numberList')) {
        numberList = JSON.parse(storage.getItem('numberList'));
        numberList.forEach(function (e) {
          numberListHtml += '<li><label>' + e + '</label><div class="btn-del"><i>x</i></div></li>';
        });
        $('.lottery-list ul').append(numberListHtml);
      }
      //获取奖项，奖品信息
      //mock
      // prizeInfo = [{
      //   "id": 1,
      //   "name": "幸运奖",
      //   "pic": "/luck.jpg",
      //   "gifts": [{
      //     "id": 1,
      //     "name": "200元京东卡",
      //     "pic": "/kkk.jpg"
      //   }]
      // }, {
      //   "id": 2,
      //   "name": "一等奖",
      //   "pic": "/luck.jpg",
      //   "gifts": [{
      //     "id": 222,
      //     "name": "1000元京东卡",
      //     "pic": "/kkk.jpg"
      //   }, {
      //     "id": 333,
      //     "name": "2000元京东卡",
      //     "pic": "/kkk.jpg"
      //   }, {
      //     "id": 444,
      //     "name": "3000元京东卡",
      //     "pic": "/kkk.jpg"
      //   }]
      // }];
      // prizeInfo.forEach(function (e) {
      //   typeHtml += '<option value =' + e.id + '>' + e.name + '</option>';
      // });
      // self.setPrizeNameList(prizeInfo[0].gifts);
      // $('.type-select').append(typeHtml);
      //end-mock

      $.ajax({
        url:oConfig.oUrl.getPrizeInfo,
        type:'GET',
        dataType:'JSON',
        data:{}
      })
      .done(function(msg){
        if(0 == msg.code){
          msg.data.forEach(function(e){
            typeHtml +=  '<option value ='+e.id+'>'+e.name+'</option>'
          })
          prizeInfo =  msg.data
          self.setPrizeNameList(prizeInfo[0].gifts)
          $('.type-select').append(typeHtml)
        }
      })
    }
    //清空编号
    , clearNumberLi: function clearNumberLi() {
      $('.lottery-list ul').empty();
      numberList = [];
    }
  };
  oPage.init();
});