// import { setTimeout } from "timers";

/* ==========================================================
* index.js v20180119
* ==========================================================
* by huhuiling
*
* 1、年会录入
* ========================================================== */
$(function() {
  var oConfig = window.oPageConfig;
  var ui = {
    $pop:$('.v-message'),
    $btnUpdatePrize:$('.js-update-prize'),//更新奖品
    $btnCloseLottery:$('.js-close-lottery'),//关闭
    $typeSelect:$('.prize-set .type-select'),//类别选择
    $nameSelect:$('.prize-set .name-select'),//名称选择
    $btnSwitch:$('.btn-switch-screen'),//切屏
    $formNumber:$('.js-form-number')
  };
  var numberList = [];//编号
  var prizeInfo = [];//奖项 奖品信息
  var storage = window.localStorage;
  var oPage = {
    init: function() {
      this.view();
      this.listen();
      // this.typeChange()
    }
  , view: function() {
      var self = this;
    }
  , listen: function() {
      var self = this;
      var tabIdx = 0,        //当前tab页
          lotteryItem = '',  //中奖单个li
          keyNumber = '',    //输入的编号
          delItemIdx = '',   //删除项的index
          param = {};        //中奖li 
      //init 初始渲染
      self.initPrizeInfo()
      //tab切换
      $('.tab-list .tab-item').on('click',function(){
        self.loadLotteryTable()
        $(this).addClass('active').siblings().removeClass('active');
        tabIdx =  $(this).index();
        $('.tab-cont .tab-pane').eq(tabIdx).addClass('active').siblings().removeClass('active')

      })
      //公共 监听select值变化
      $('.type-select').change(function(e){
        prizeInfo.forEach(function(item){
          if(item.id == e.target.value){
            self.setPrizeNameList(item.gifts)
            return
          }
        })
      })
      ui.$typeSelect.change(function(){
        self.clearNumberLi()
      })
      ui.$nameSelect.change(function(){
        self.clearNumberLi()
      })    
      //输入
      $('.number-input').on('keydown',function(e){
        keyNumber = $('.number-input').val()
        lotteryItem = '<li><label>'+keyNumber+'</label><div class="btn-del"><i>x</i></div></li>'
        //回车录入
        if(e.keyCode == "13" && keyNumber != '') {
          var hasNumberIdx = $.inArray(keyNumber,numberList);
          if(hasNumberIdx != -1){
            $('.lottery-list li').eq(hasNumberIdx).addClass('bgWarning')
            setTimeout(function(){ $('.lottery-list li').eq(hasNumberIdx).removeClass('bgWarning')},1000)
          }else{
            $('.lottery-list ul').append(lotteryItem);
            numberList.push(keyNumber)
            storage.setItem('numberList',JSON.stringify(numberList)) 
            $('.number-input').val('') 
          }

        }        
      })
      //删除中奖名单
      $('.lottery-list').on('click','.btn-del',function(e){
        delItemIdx = $(this).closest('li').index()
        $('.lottery-list li').eq(delItemIdx).remove()
        numberList.splice(delItemIdx,1)
        storage.setItem('numberList',JSON.stringify(numberList))//本地更新存储 numberList
      })

      //提交 奖品信息 按钮变成关闭状态，奖项不可选
      $('.btn-update-prize').on('click',function(){
        if(confirm('确认更新奖品信息？')){
          param = {
            pid: $('.type-select').val(),
            gid: $('.name-select').val(),
          }
          //mock
          // self.startLottery()  //按钮变化
          // self.clearNumberLi() //清除中奖编号
          // self.popIn('success','开始本轮抽奖成功！')
          //end mock
          $.ajax({
            url:oConfig.oUrl.screenPrize,
            type:'put',
            dataType:'JSON',
            data:param
          })
          .done(function(msg){
            if(0 == msg.code){
              self.popIn('success','本轮抽奖已开始，请输入中奖编号！')
              self.startLottery()
              self.clearNumberLi()
            }else{
              self.popIn('error',msg.message)
            }
          })
        }       
      })
      // 关闭 抽奖信息展示
      ui.$btnCloseLottery.on('click',function(){
        //mock
        // self.popIn('success','关闭抽奖成功！')
        // self.endLottery()
        // self.clearNumberLi()
        //end mock
        if(confirm('确认关闭抽奖？')){
          $.ajax({
            url:oConfig.oUrl.closeLottery,
            type:'put',
            dataType:'JSON',
            data:{}
          })
          .done(function(msg){
            if(0 == msg.code){
              self.popIn('success','本轮抽奖已结束！')
              self.endLottery()
              self.clearNumberLi()
            }else{
              self.popIn('error',msg.message)
            }
          })

        }
       
      })
      //切屏
      ui.$btnSwitch.on('click',function(){
        if(confirm('确认切换屏幕至视频直播？')){
          $.ajax({
            url:oConfig.oUrl.switchScreen,
            type:'put',
            dataType:'JSON',
            data:{}
          })
          .done(function(msg){
            if(0 == msg.code){
              self.popIn('success','切屏成功！')
            }else{
              self.popIn('error',msg.message)
            }
          })

        }
       
      });      
      //提交 中奖编号
      $('.btn-update-number').on('click',function(){
        if(confirm('确认更新中奖编号？')){
          param = {
            pid: $('.type-select').val(),
            gid: $('.name-select').val(),
            numList:numberList,
          }
          storage.setItem('numberList',JSON.stringify(numberList)) 
          $.ajax({
            url:oConfig.oUrl.screenLotteryNumber,
            type:'put',
            dataType:'JSON',
            data:param
          })
          .done(function(msg){
            if(0 == msg.code){
              self.popIn('success','更新中奖编号成功！')
              self.clearNumberLi()
            }else{
              self.popIn('error',msg.message)
            }
           
          })
        }

      })
      $('.btn-search').on('click',function(){
        self.loadLotteryTable()
      })
    }
  //奖品名称变化
  , setPrizeNameList:function(gifts){
      let prizeNameHtml = ''
      gifts.forEach(function(i){
        prizeNameHtml +=  '<option value ='+i.id+'>'+i.name+'</option>'
      })
      $('.name-select').html(prizeNameHtml)
    }
  //初始渲染
    //中奖table 
  , loadLotteryTable(){
      var tableHtml = '' 
      var param = {
        pid:$('.prize-list .type-select').val(),
        gid:$('.prize-list .name-select').val(),
        num:$('.prize-list .number').val()
      };
    //mock 
    //  var tableData = [
    //   {
    //     "draw_num": 115,
    //     "prize": "幸运奖",
    //     "gift": "300元京东卡",
    //     "created_at": "2018-01-22 09:28:25"
    //   },
    //   {
    //     "draw_num": 105,
    //     "prize": "幸运奖",
    //     "gift": "200元京东卡",
    //     "created_at": "2018-01-22 09:28:25"
    //   }
    //  ]
    // tableData.forEach(function(item){
    //   tableHtml = '<tr><td>'+item.prize+'</td><td>'+item.gift+'</td><td>'+item.draw_num+'</td><td>'+item.created_at+'</td></tr>'
    // })
    // $('table tbody').html(tableHtml)
    //end mock
    $.ajax({
      url:oConfig.oUrl.lotteryRecords,
      type:'GET',
      dataType:'JSON',
      data:param
    })
    .done(function(msg){
      if(0 == msg.code){
        msg.data.forEach(function(item){
          tableHtml = '<tr><td>'+item.prize+'</td><td>'+item.gift+'</td><td>'+item.draw_num+'</td><td>'+item.created_at+'</td></tr>'
        })
        $('table tbody').html(tableHtml)         
      }
    })    
    }
    //奖品信息
  , initPrizeInfo:function(){
      var self = this;
      var  numberListHtml = '',
           typeHtml = '',
           prizeType = [],
           prizeName = [],
           typeIdx = 0;
      // ui.$btnSwitch.css('display','none')//未开始抽奖 ，切屏按钮不显示     
      ui.$formNumber.css('display','none')//未开始抽奖 ，号码不展示
      if(storage.getItem('numberList')){
        numberList = JSON.parse(storage.getItem('numberList'))
        numberList.forEach(function(e){
          numberListHtml += '<li><label>'+e+'</label><div class="btn-del"><i>x</i></div></li>'
        })
        $('.lottery-list ul').html(numberListHtml)
      }
      //获取奖项，奖品信息
      //mock
    //  var data = {
    //    list:[
    //     {
    //       "id": 1,
    //       "name": "幸运奖",
    //       "pic": "/luck.jpg",
    //       "gifts": [
    //         {
    //           "id": 1,
    //           "name": "200元京东卡",
    //           "pic": "/kkk.jpg"
    //         }
    //       ]
    //     },
    //     {
    //       "id": 2,
    //       "name": "一等奖",
    //       "pic": "/luck.jpg",
    //       "gifts": [
    //         {
    //           "id": 222,
    //           "name": "1000元京东卡",
    //           "pic": "/kkk.jpg"
    //         },
    //         {
    //           "id": 333,
    //           "name": "2000元京东卡",
    //           "pic": "/kkk.jpg"
    //         },
    //         {
    //           "id": 444,
    //           "name": "3000元京东卡",
    //           "pic": "/kkk.jpg"
    //         }
    //       ]
    //     }        
    //    ],
    //    curPrize:{
    //      pid:2,
    //      gid:444,
    //      status:1
    //    }
    //  }
    //   prizeInfo = data.list;
    //   prizeInfo.forEach(function(e,idx){
    //     typeHtml +=  '<option value ='+e.id+'>'+e.name+'</option>'
    //     if(data.curPrize.status && e.id == data.curPrize.pid){
    //       typeIdx = idx
    //     }
    //   })
    //   self.setPrizeNameList(prizeInfo[typeIdx].gifts)
    //   //初始奖项奖品配置 status != 0
    //   if(data.curPrize.status){
    //     setTimeout(function(){
    //       ui.$typeSelect.val(data.curPrize.pid)
    //       ui.$nameSelect.val(data.curPrize.gid)
    //     },0)
    //     self.startLottery()
    //   }
    //   $('.type-select').html(typeHtml)
      //end-mock
      $.ajax({
        url:oConfig.oUrl.getPrizeInfo,
        type:'GET',
        dataType:'JSON',
        data:{}
      })
      .done(function(msg){
        if(0 == msg.code){
          prizeInfo = msg.data.list;
          prizeInfo.forEach(function(e,idx){
            typeHtml +=  '<option value ='+e.id+'>'+e.name+'</option>'
            if(msg.data.curPrize.status && e.id == msg.data.curPrize.pid){
              typeIdx = idx
            }
          })
          self.setPrizeNameList(prizeInfo[typeIdx].gifts)
          //初始奖项奖品配置 status != 0
          if(msg.data.curPrize.status){
            setTimeout(function(){
              ui.$typeSelect.val(msg.data.curPrize.pid)
              ui.$nameSelect.val(msg.data.curPrize.gid)
            },0)
            self.startLottery()
          }
          $('.type-select').html(typeHtml)
        }
      })
    }
    //清空编号
  , clearNumberLi:function(){
      $('.lottery-list ul').empty()
      numberList = []
    }
    //开启抽奖
   , startLottery:function(){
      ui.$btnUpdatePrize.css('display','none')
      ui.$btnCloseLottery.css('display','inline-block')
      ui.$btnSwitch.css('display','inline-block')
      ui.$formNumber.css('display','block')
      ui.$typeSelect.attr('disabled','disabled')
      ui.$nameSelect.attr('disabled','disabled')
    }
  ,  endLottery:function(){
      ui.$btnUpdatePrize.css('display','inline-block')
      ui.$btnCloseLottery.css('display','none')
      ui.$btnSwitch.css('display','none')
      ui.$formNumber.css('display','none')
      ui.$typeSelect.attr('disabled',false)
      ui.$nameSelect.attr('disabled',false)
    } 
  , popIn:function(type,txt){
      ui.$pop.attr('class','v-message '+type);
      ui.$pop.fadeIn().delay(1000).fadeOut();
      ui.$pop.find('.v-message-content-desc').html(txt)
    }    
  };
  oPage.init();
});