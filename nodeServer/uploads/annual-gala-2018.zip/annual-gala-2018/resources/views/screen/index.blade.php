<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>边锋网络科技-2017年会</title>
    <link rel="stylesheet" type="text/css" href="{{URL::asset('pm_nianhui/dist/assets/c/reset.css')}}">
    <link rel="stylesheet" type="text/css" href="{{URL::asset('pm_nianhui/dist/assets/c/index.css')}}">
</head>
<body>

<!-- 吱口令 横幅 -->
<div class="top-streamer" style="display:none;">
    <ul class="zfb-container">
    </ul>
</div>
<div class="bg-main">
    <img src="{{URL::asset('pm_nianhui/dist/assets/i/bg2.png')}}" class="beijin" alt="背景">
</div>
<!-- 吱口令 横幅 end-->

<!-- 吱口令 红包 -->
<div class="hong-bao small" style="display: none">
    <img src="{{URL::asset('pm_nianhui/dist/assets/i/hongbao.png')}}">
    <div class="hong-bao-content hide"></div>
    <div class="hong-bao-token hide align-center-vertical"></div>
</div>
<!-- 吱口令 红包 end-->

<!-- 奖品展示 -->
<div class="prize-goods" style="display:none;">
    <div class="luck-prize-name"></div>
    <div class="prize-goods-beijin">
        <span class="prize-goods-name"></span>
        <div><img src="{{URL::asset('pm_nianhui/dist/assets/i/prize.png')}}" class="prize-goods-src"></div>
    </div>
</div>
<div class="prize-goods" style="display:none;">
    <div class="luck-prize-name"></div>
    <div class="prize-goods-beijin">
        <span class="prize-goods-name"></span>
        <div><img src="{{URL::asset('pm_nianhui/dist/assets/i/prize.png')}}" class="prize-goods-src"></div>
    </div>
</div>
<!-- 奖品展示 end-->

<!-- 获奖名单 -->
<div class="luck-main">
    <div class="lucker-user-show clearfix">
        <div class="lucker-user-show-main clearfix">
            <div class="lucker-user-show-title"></div>
            <div class="lucker-user-show-number">
            </div>
        </div>
    </div>
</div>

<!-- 获奖名单 end-->

<!-- 弹幕 -->
<div id="my-container" class="tanmu-container">
</div>
<!-- 弹幕 end-->

<div class="error-message hide">网络异常，请检查网络！</div>
<script>
    window.oPage = {
        imgs: {
            usersBg: "{{URL::asset('pm_nianhui/dist/assets/i/bg.png')}}",  //获奖名单背景
            tanmuBg: "{{URL::asset('pm_nianhui/dist/assets/i/bg2.png')}}",
            hongbaoTextPng: "{{URL::asset('pm_nianhui/dist/assets/i/hongbaoText.png')}}",
            hongbaoPng: "{{URL::asset('pm_nianhui/dist/assets/i/hongbao.png')}}",
        },
        wsHost: "{{env('WS_SERVER')}}"
    }
</script>
<script src="{{URL::asset('pm_nianhui/dist/assets/j/tool.js')}}"></script>
<script src="{{URL::asset('pm_nianhui/dist/assets/libs/jquery-1.9.1.min.js')}}"></script>
<script src="{{URL::asset('pm_nianhui/dist/assets/j/jquery.easing.1.3.js')}}"></script>
<script src="{{URL::asset('pm_nianhui/dist/assets/j/danmaku.min.js')}}"></script>
<script src="{{URL::asset('pm_nianhui/dist/assets/j/emotion.js')}}"></script>
<script src="{{URL::asset('pm_nianhui/dist/assets/j/index.js?v2')}}"></script>
</body>
</html>