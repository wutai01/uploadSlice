<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>年会后台</title>
    <link rel="stylesheet" href="{{URL::asset('pc_nianhui/c/reset.css')}}">
    <link rel="stylesheet" href="{{URL::asset('pc_nianhui/c/index.css')}}">
</head>
<body>
<div class="wrap">
    <h1 class="text-center">年会中奖配置</h1>
    <div class="tab-body">
        <button class="c-btn btn-switch-screen">切屏</button>
        <ul class="tab-list clearfix">
            <li class="tab-item active">
                <a href="javascript:;">中奖名单设置</a>
            </li>
            <li class="tab-item">
                <a href="javascript:;">中奖信息列表</a>
            </li>
        </ul>
        <div class="tab-cont">
            <div class="tab-pane active prize-set">
                <div class="tips">提示：点击<span class="text-green"> 开始本轮抽奖</span>，屏幕展示当前抽奖的奖品信息。点击<span class="text-red"> 结束本轮抽奖 </span>结束本轮抽奖。点击<span class="text-yellow"> 更新中奖编号</span> 提交当前录入编号，屏幕展示当前抽奖的奖品信息以及中奖编号。
                    点击<span class="text-green"> 切屏 </span>关闭抽奖信息展示切换至视频直播模式。
                </div>
                <div class="form-group">
                    <label for="">奖项类别</label>
                    <select class="prize-select-list type-select"></select>
                </div>
                <div class="form-group">
                    <label for="">奖品名称</label>
                    <select class="prize-select-list name-select"></select>
                    <button class="c-btn btn-update-prize js-update-prize">开始本轮抽奖</button>
                    <button class="c-btn btn-danger btn-close-lottery js-close-lottery">结束本轮抽奖</button>
                </div>
                <div class="form-group js-form-number">
                    <label for="">中奖编号</label>
                    <input type="number" placeholder="请输入奖品编号，按回车键录入" class="number-input"></input>
                    <button class="c-btn btn-warning btn-update-number">更新中奖编号</button>
                </div>
                <div class="lottery-list js-form-number"><ul></ul></div>
            </div>
            <div class="tab-pane prize-list clearfix">
                <div class="clearfix">
                    <div class="form-group c-form-group">
                        <label for="">奖项类别</label>
                        <select class="prize-select-list type-select"></select>
                    </div>
                    <div class="form-group c-form-group">
                        <label for="">奖品名称</label>
                        <select class="prize-select-list name-select"></select>
                    </div>
                    <div class="form-group c-form-group">
                        <label for="">奖品编号</label>
                        <input type="number" placeholder="请输入奖品编号" class="number"></input>
                    </div>
                    <button class="c-btn btn-search">搜索</button>
                </div>

                <table class="table table-striped table-hover text-center">
                    <thead>
                    <tr>
                        <th>奖项类别</th>
                        <th>奖品名称</th>
                        <th>中奖编号</th>
                        <th>中奖时间</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<div class="v-message success" style="z-index: 2023;">
    <div class="v-message-content">
        <div class="v-message-content-icon">
            <span class="icon-txt txt-success">√</span>
            <span class="icon-txt txt-error">×</span>
        </div>
        <p class="v-message-content-desc"></p>
    </div>
</div>
<script type="text/javascript">
    // 配置参数
    window.oPageConfig = {
        oUrl: {
            'getPrizeInfo': '/api/happy-new-year/prizes',
            'screenPrize':'/api/happy-new-year/screen/prize',
            'screenLotteryNumber':'/api/happy-new-year/screen/prize-user',
            'lotteryRecords':'/api/happy-new-year/lottety/records',
            'closeLottery':'/api/happy-new-year/screen/prize/end',
            'switchScreen':'/api/happy-new-year/screen/switch',
        }
    };
    // function nameChange(e){
    //   console.log(e)
    // }
</script>
<script type="text/javascript" src='{{URL::asset('pc_nianhui/j/lib/jquery-1.12.4.min.js')}}'></script>

<script type="text/javascript" src="{{URL::asset('pc_nianhui/j/index.js')}}"></script>
</body>
</html>