<!DOCTYPE html>
<html>
<head>
    <title>口令红包</title>
    <meta charset="utf-8">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="format-detection" content="telephone=no,email=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=no">
    <meta name="fitsetting" content="width=750,height=1206,mode=0,scale=0">
    <!--STYLE_PLACEHOLDER-->
    <link rel="stylesheet" href="{{URL::asset('mb_nianhui/c/lib/reset.css')}}">
    <link rel="stylesheet" href="{{URL::asset('mb_nianhui/c/redpacket.css')}}">
    <script src="{{URL::asset('mb_nianhui/j/lib/screen-adaptor.js')}}"></script><!--ignore-->
</head>
<body>
<div class="wrap">
    <h2>口令红包</h2>
    <div class="form">
        <div class="form-group">
            <label for="">发送者：</label>
            <input type="index"/ maxlength="6" class="j-send-name">
        </div>
        <div class="form-group">
            <label for="">口令：</label>
            <textarea rows="3" cols="20" maxlength="20" class="js-token"></textarea>
        </div>
    </div>

    <!-- <button>发送红包</button>     -->
    <div class="btn-wrap">
        <div class="btn-send js-btn-send">发送红包</div>
    </div>

</div>
<script>
    window.oPageConfig = {
        oUrl: {
            'sendRedpacket': '/api/happy-new-year/leader/redpack',
        }
    };
</script>

<script src="{{URL::asset('mb_nianhui/j/lib/jquery-3.1.1.min.js')}}" ></script><!--ignore-->
<script src="{{URL::asset('mb_nianhui/j/sendRedpacket.js')}}"></script>
</body>
</html>