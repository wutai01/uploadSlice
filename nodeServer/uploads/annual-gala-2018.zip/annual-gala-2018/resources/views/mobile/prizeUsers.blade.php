<!DOCTYPE html>
<html>
<head>
    <title>年会中奖名单</title>
    <meta charset="utf-8">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="format-detection" content="telephone=no,email=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=no">
    <meta name="fitsetting" content="width=750,height=1206,mode=0,scale=0">
    <!--STYLE_PLACEHOLDER-->
    <link rel="stylesheet" href="{{URL::asset('mb_nianhui/c/lib/reset.css')}}">
    <link rel="stylesheet" href="{{URL::asset('mb_nianhui/c/detail.css')}}">
    <script src="{{URL::asset('mb_nianhui/j/lib/screen-adaptor.js')}}"></script><!--ignore-->
</head>
<body>
<div class="wrap">
    <div>
        <h2 class="lottery-type">{{$info['gift']['prize_name']}}</h2>
        <p class="lottery-name">{{$info['gift']['gift_name']}}</p>
        <div class="lottery-img">
            <img class="show-info" src="{{URL::asset($info['gift']['pic'])}}" alt=""/>
        </div>
        <div class="lottery-number-list">
            <p class="title">中奖名单</p>
            <ul class="clearfix js-number-ul">
                @foreach($info['numList'] as $one)
                <li>{{$one}}</li>
                @endforeach
            </ul>
            <p class="no-data">暂无中奖名单</p>
        </div>

    </div>
</div>
<script>
    window.oPageConfig = {
        oUrl: {
            'getUserInfo': '/api/user',
        }
    };
</script>

<script src="{{URL::asset('mb_nianhui/j/lib/jquery-3.1.1.min.js')}}" ></script><!--ignore-->
<script src="{{URL::asset('mb_nianhui/j/index.js')}}"></script>
</body>
</html>