<!DOCTYPE html>
<html data-dpr="2" style="font-size: 100px;">
<head>
    <title>年会中奖名单</title>
    <meta charset="utf-8">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="format-detection" content="telephone=no,email=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=no">
    <meta name="fitsetting" content="width=750,height=1206,mode=0,scale=0">
    <!--STYLE_PLACEHOLDER-->
    <link rel="stylesheet" href="{{URL::asset('mb_nianhui/c/lib/reset.css')}}">
    <link rel="stylesheet" href="{{URL::asset('mb_nianhui/c/index.css')}}">
    <script src="{{URL::asset('mb_nianhui/j/lib/screen-adaptor.js')}}"></script><!--ignore-->
</head>
<body>
<div class="wrap">
    <div class="search-bar-wrap">
        <div class="search-bar">
            <input class="num-input" type="number" pattern="[0-9]*" placeholder="输入编号搜索中奖信息..." />
            <div class="btn-search js-search">
                <i class="icon icon-search"></i>
            </div>
            <div class="btn-clear js-clear">
                <i class="icon icon-clear"></i>
            </div>
        </div>
        <div class="btn-cancel js-cancel">取消</div>
    </div>

    <ul class="card-wrap clearfix">
        @foreach($list as $k => $one)
        <!--幸运奖-->
        <li class="card-item @if($one['status'] == 1) show @endif">
            <h2 class="lottery-type">{{sprintf("%02d", $k+1)}}. {{$one['prize']}}</h2>
            <p class="lottery-name">
            @if($one['status'] == 0)
                    <span>???</span>
            @else
                    <span>{{$one['gift']}}</span>
            @endif
            </p>
            <div class="lottery-img">
                @if($one['status'] == 0)
                    <p>?</p>
                @else
                    <img src="{{URL::asset($one['pic'])}}" alt="暂无图片"/>
                @endif

            </div>
            <div class="lottery-tip">
                @if($one['status'] == 0)
                    <span>敬请期待</span>
                @else
                    <a href="{{url('mobile/prize/users')}}?gift={{$one['gid']}}"><span class="btn-detail">查看中奖名单</span></a>
                @endif
            </div>
        </li>
        @endforeach
    </ul>
    <div class="mask-wrap">
        <div class="mask-cont"></div>
    </div>
</div>
<script>
    window.oPageConfig = {
        oUrl: {
            'getUserInfo': '/api/happy-new-year/lottety/records',
        }
    };
</script>

<script src="{{URL::asset('mb_nianhui/j/lib/jquery-3.1.1.min.js')}}" ></script><!--ignore-->
<script src="{{URL::asset('mb_nianhui/j/index.js')}}?v11"></script>
</body>
</html>