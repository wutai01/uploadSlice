<?php

return [
    'redis_prefix' => 'annual',
    'wechat'       => [
        'app_id'     => 'wxf5e4ee41253548e4',
        'app_secret' => 'c3a8a17999438bfc19fbb0ada6c64355'
    ],
    'prize_name' => [
        '惊喜奖' => 1,
        '特等奖' => 2,
        '一等奖' => 3,
        '二等奖' => 4,
        '三等奖' => 5,
        '好运奖' => 6,
        '幸运奖' => 7,
    ],
    'prizes'       => [
        [
            'name'  => '惊喜奖',
            'pics'  => '',
            'order' => 1,
            'gifts' => [
                [
                    'name'  => 'MacBook Pro',
                    'pics'  => 'mb_nianhui/images/surprise.jpg|assets/img/prizes/1-1.png',
                    'order' => 1,
                ]
            ],
        ],
        [
            'name'  => '特等奖',
            'pics'  => '',
            'order' => 2,
            'gifts' => [
                [
                    'name'  => 'iPhone X',
                    'pics'  => 'mb_nianhui/images/special.jpg|assets/img/prizes/2-1.png',
                    'order' => 1,
                ]
            ],

        ],
        [
            'name'  => '一等奖',
            'pics'  => '',
            'order' => 3,
            'gifts' => [
                [
                    'name'  => 'GoPro HERO 6',
                    'pics'  => 'mb_nianhui/images/first-1.jpg|assets/img/prizes/3-1.png',
                    'order' => 1
                ],
                [
                    'name'  => 'Apple Watch Series 3',
                    'pics'  => 'mb_nianhui/images/first-2.jpg|assets/img/prizes/3-2.png',
                    'order' => 2
                ],
                [
                    'name'  => 'iPad 128G WLAN版',
                    'pics'  => 'mb_nianhui/images/first-3.jpg|assets/img/prizes/3-3.png',
                    'order' => 3
                ],
            ],

        ],
        [
            'name'  => '二等奖',
            'pics'  => '',
            'order' => 4,
            'gifts' => [
                [
                    'name'  => '任天堂Switch 游戏机 ns',
                    'pics'  => 'mb_nianhui/images/second-1.jpg|assets/img/prizes/4-1.png',
                    'order' => 1
                ],
                [
                    'name'  => '微软 Xbox One S',
                    'pics'  => 'mb_nianhui/images/second-2.jpg|assets/img/prizes/4-2.png',
                    'order' => 2
                ],
                [
                    'name'  => '索尼 无线立体声耳机',
                    'pics'  => 'mb_nianhui/images/second-3.jpg|assets/img/prizes/4-3.png',
                    'order' => 3
                ],
                [
                    'name'  => '美的 扫地机器人',
                    'pics'  => 'mb_nianhui/images/second-4.jpg|assets/img/prizes/4-4.png',
                    'order' => 4
                ],
                [
                    'name'  => '法国大使拉杆箱',
                    'pics'  => 'mb_nianhui/images/second-5.jpg|assets/img/prizes/4-5.png',
                    'order' => 5
                ],
            ],

        ],
        [
            'name'  => '三等奖',
            'pics'  => '',
            'order' => 5,
            'gifts' => [
                [
                    'name'  => '阿尔郎 电动平衡车',
                    'pics'  => 'mb_nianhui/images/third-1.jpg|assets/img/prizes/5-1.png',
                    'order' => 1,
                ],
                [
                    'name'  => '洛斐 毒奏蓝牙音箱',
                    'pics'  => 'mb_nianhui/images/third-2.jpg|assets/img/prizes/5-2.png',
                    'order' => 2,
                ],
            ]
        ],
        [
            'name'  => '好运奖',
            'pics'  => '',
            'order' => 6,
            'gifts' => [
                [
                    'name'  => '德尔玛 加湿器',
                    'pics'  => 'mb_nianhui/images/goodluck-1.jpg|assets/img/prizes/6-1.png',
                    'order' => 1,
                ],
                [
                    'name'  => '飞利浦 电动牙刷',
                    'pics'  => 'mb_nianhui/images/goodluck-2.jpg|assets/img/prizes/6-2.png',
                    'order' => 2,
                ],
                [
                    'name'  => '洛斐 蓝牙机械键盘',
                    'pics'  => 'mb_nianhui/images/goodluck-3.jpg|assets/img/prizes/6-3.png',
                    'order' => 3,
                ],
                [
                    'name'  => 'LAMY凌美 钢笔',
                    'pics'  => 'mb_nianhui/images/goodluck-4.jpg|assets/img/prizes/6-4.png',
                    'order' => 4,
                ],
                [
                    'name'  => '蒙马特防盗背包',
                    'pics'  => 'mb_nianhui/images/goodluck-5.jpg|assets/img/prizes/6-5.png',
                    'order' => 5,
                ],
            ]
        ],
        [
            'name'  => '幸运奖',
            'pics'  => '',
            'order' => 7,
            'gifts' => [
                [
                    'name'  => '京东卡',
                    'pics'  => 'mb_nianhui/images/card.jpg|assets/img/prizes/7-1.png',
                    'order' => 1
                ],
                [
                    'name'  => '乐心 运动手环',
                    'pics'  => 'mb_nianhui/images/luck-1.jpg|assets/img/prizes/7-2.png',
                    'order' => 2
                ],
            ]
        ]
    ],
];