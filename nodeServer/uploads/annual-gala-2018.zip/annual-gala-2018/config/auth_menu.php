<?php

return [
    // 应用名称
    'name' => 'Gala-2018',

    // 菜单，ops为该菜单下的
    'menu' => [
        [
            'icon' => 'fa fa-list',
            'url'  => '/user-prize', // 如果是客户端，则请填写自定义的值，用来判断权限
            'name' => '添加中奖信息',
            'ops'  => [

            ],
        ],
        [
            'icon' => 'fa fa-list',
            'url'  => '/user-prize/search/', // 如果是客户端，则请填写自定义的值，用来判断权限
            'name' => '中奖信息查询',
            'ops'  => [

            ],
        ],
    ]
];