<?php
/**
 * UserPrize.php
 * User: wanghui03
 * Date: 2018/1/18
 * Time: 13:44
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserPrize extends Model
{
    const STATUS_UNGET = 0;
    const STATUS_GET   = 1;

    public $timestamps = false;

    protected $table = 'user-prize';

    public $fillable = [
        'id',
        'draw_num',
        'prize',
        'gift',
        'status',
        'created_at',
    ];
}