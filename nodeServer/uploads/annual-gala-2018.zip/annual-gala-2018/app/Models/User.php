<?php
/**
 * User.php
 * User: wanghui03
 * Date: 2018/1/18
 * Time: 13:43
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = 'users';

    public $timestamps = false;

    protected $fillable = [
        'id',
        'openid',
        'nickname',
        'headimgurl',
        'role',
        'draw_num',
        'barrage_num',
        'status',
    ];
}