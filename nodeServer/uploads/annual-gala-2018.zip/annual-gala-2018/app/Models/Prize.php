<?php
/**
 * Prize.php
 * User: wanghui03
 * Date: 2018/1/18
 * Time: 13:44
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prize extends Model
{
    protected $table = 'prizes';

    public $timestamps = false;

    protected $fillable = [
        'id',
        'name',
        'pics',
        'pid',
        'status',
        'order',
    ];
}
