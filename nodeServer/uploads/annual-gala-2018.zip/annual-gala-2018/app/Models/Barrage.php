<?php
/**
 * Barrage.php
 * User: wanghui03
 * Date: 2018/1/18
 * Time: 13:43
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Barrage extends Model
{
    // 弹幕类型
    const TYPE_NORMAL  = 1;
    const TYPE_REDPACK = 2;

    protected $table = 'barrage';

    public $timestamps = false;

    protected $fillable = [
        'id',
        'openid',
        'msgId',
        'content',
        'nickname',
        'headimgurl',
        'type',
        'created_at',
    ];
}