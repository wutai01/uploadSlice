<?php

namespace App\BoxAuthLaravel;

class AuthException extends \Exception
{
    const REQUEST_TIMED_OUT = 10000;
    const USER_INFO_NOT_FOUND = 10001;
    const CODE_NOT_MATCH = 10002;
    const PARAMETER_MISS = 10003;
    const NO_PRIVILEGE = 10004;
    const AUTH_TYPE_NOT_SUPPORTED = 10005;
    const TICKET_NOT_FOUND = 10006;
    const ROUTE_ACCESS_FORBID = 10007;
    const SIGN_NOT_CORRECT = 10008;
    const INCORRECT_JSON_PACKET = 10009;
    const APP_NOT_EXISTS = 10010;
    const ACCOUNT_LOCKED = 10011;
    const ACCOUNT_VERIFY_FAILED = 10012;
    const APP_SETTING_INCORRECT = 10013;
    const APP_NOT_AUTHORIZED = 10014;
    const ACCOUNT_NOT_BOUND_PHONE = 10015;
    const SMS_CODE_EXPIRED_OR_NOT_EXISTS = 10016;
    const SCOPE_INFO_NOT_FOUND = 10017;
    const ROLE_INFO_NOT_FOUND = 10018;
    const UNDEFINED_ERROR = 10099;
    const TICKET_OVER_TIME = 10020;
    const APPID_NOT_CORRECT = 10021;

    public static function throwException($code)
    {
        $messages = [
            self::REQUEST_TIMED_OUT => '请求鉴权服务超时，请重试。',
            self::USER_INFO_NOT_FOUND => '用户信息未找到，请联系管理员。',
            self::CODE_NOT_MATCH => '密码（安全码）不匹配。',
            self::PARAMETER_MISS => '参数缺失，请查看API文档。',
            self::NO_PRIVILEGE => '您没有权限访问。',
            self::AUTH_TYPE_NOT_SUPPORTED => '验证方式不支持，请确认你的验证类型。',
            self::TICKET_NOT_FOUND => '找不到令牌？请重新登录。',
            self::ROUTE_ACCESS_FORBID => '路径权限未开通，无法访问此页面。',
            self::SIGN_NOT_CORRECT => '签名不正确，请查看API文档。',
            self::APP_NOT_EXISTS => '应用(缓存）不存在，请联系管理员配置应用。',
            self::ACCOUNT_LOCKED => '账户锁定中，请稍后再试。',
            self::ACCOUNT_VERIFY_FAILED => '账户验证失败，请重试。',
            self::APP_SETTING_INCORRECT => '应用设置（缓存）不正确，请联系管理员。',
            self::APP_NOT_AUTHORIZED => '应用未授权，请联系管理员授权。',
            self::INCORRECT_JSON_PACKET => '请求失败，不正确的JSON数据包，请联系管理员。',
            self::ACCOUNT_NOT_BOUND_PHONE => '账户尚未绑定手机号。',
            self::SCOPE_INFO_NOT_FOUND => '应用作用域不存在。',
            self::SMS_CODE_EXPIRED_OR_NOT_EXISTS => '短信验证码不存在或者已过期，请重新获取。',
            self::ROLE_INFO_NOT_FOUND => '角色不存在。',
            self::SCOPE_INFO_NOT_FOUND => '应用作用域不存在。',
            self::TICKET_OVER_TIME => '新接口Ticket过期',
            self::APPID_NOT_CORRECT => '新接口ticket对应的appId错误',

        ];
        throw new self($messages[$code], $code);
    }
}