<?php
/**
 * box验证处理者
 * 配置读取和设置，验证接口请求
 *
 * User: wangchao02
 * Email: wangchao02@bianfeng.com
 * created: 2016-12-9 09:57
 */

namespace App\BoxAuthLaravel;

use Illuminate\Support\Facades\Session;

class BoxAuth
{
    /** @var AuthClient $authClient */
    public $authClient;

    /**
     * @var array 用户属性数组
     */
    protected $user;

    protected $route;

    /**
     * @var array 权限列表[包含菜单]
     */
    protected $privileges = [];

    protected function init()
    {
        $this->authClient = new BoxAuthClient();
        $this->authClient->appId = $this->getAppId();
        $this->authClient->appKey = $this->getAppKey();
        $this->authClient->timeout = $this->getAuthTimeout();
        $this->authClient->server = $this->getAuthServer();
    }

    /**
     * 跳转验证的host
     * box.imeete.com
     *
     * @return string 获取认证登录Host
     */
    public function getAuthHost()
    {
        return  env('BOX_HOST', 'box.imeete.com'); // 根据测试或正式环境自行配置
    }

    /**
     * 项目的AppId
     *
     * @return mixed
     *
     */
    public function getAppId()
    {
        return env('BOX_ID', config('box.appid'));
    }

    /**
     * 项目的key
     * @return mixed
     *
     */
    public function getAppKey()
    {
        return env('BOX_KEY', config('box.appkey'));
    }

    /**
     * 获取认证服务器地址
     * 区别AuthHost 这是http请求地址不是跳转登录的地址
     *
     * @return string
     */
    public function getAuthServer()
    {
        $authServer = env('AUTH_SERVER', config('box.server'));  // 根据测试或正式环境自行配置

        if (substr($authServer, strlen($authServer) - 1, 1) != '/') {
            $authServer = $authServer . '/';
        }

        return $authServer;
    }

    /**
     * 跳转登录验证的url
     *
     * @return string 获取认证登录的url
     */
    public function getAuthUrl($redirect = '')
    {
        if (!$redirect) {
            $redirect = request()->fullUrl();
        }
        $query = http_build_query([
            'redirect' => 'http://' . $_SERVER['HTTP_HOST'] . '/auth/ticket?redirect=' . urlencode($redirect),
            'appid' => $this->getAppId(),
            'advance' => 1,
        ]);
        return 'http://' . $this->getAuthHost() . '/auth/login?' . $query;
    }

    /**
     * 进行接口验证，成功赋值user
     *
     * @return bool
     */
    public function auth()
    {
        if (!$this->authClient) {
            $this->init();
        }

        $route = $this->getRoute();
        try {
            if (is_null($route) || is_bool($route) || (is_string($route) && trim($route) === '')) {
                $data = $this->authClient->auth->info([
                    'ticket' => $this->getTicket(),
                    'advance' => 1,
                ]);
                $this->user = $data;
                $this->privileges[$this->getAppId()] = null;
                if (isset($data['authToken']) && isset($data['flushToken']) && $data['flushToken'] == 1) {
                    $this->setTicket($data['authToken']);
                }
            } else {
                $data = $this->authClient->auth->route([
                    'ticket' => $this->getTicket(),
                    'route' => $route,
                    'advance' => 1,
                ]);
                $this->user = $data['user'];
                $this->privileges[$this->getAppId()] = $data['privileges'];
                if (isset($data['authToken']) && isset($data['flushToken']) && $data['flushToken'] == 1) {
                    $this->setTicket($data['authToken']);
                }
            }
            return true;
        } catch (\Exception $e) {
            $this->processException($e);
        }
    }

    /**
     * 获取用户数据
     *
     * @return array
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * 获取权限相关数据
     *
     * @return array
     */
    public function getPrivileges()
    {
        return $this->privileges[$this->getAppId()];
    }

    /**
     * 接口超时时间
     * @return int
     */
    public function getAuthTimeout()
    {
        return 5000;
    }

    /**
     * 设置接口请求所需要的ticket/更新后的token
     *
     * @param $ticket
     */
    public function setTicket($ticket)
    {
        if ($ticket === null) {
            Session::put('LOGIN_AUTH_TICKET', '');
        }
        Session::put('LOGIN_AUTH_TICKET', $ticket);
        Session::save();
    }

    /**
     * 获取接口请求所需要的ticket/更新后的token
     *
     * @return null
     */
    public function getTicket()
    {
        return Session::get('LOGIN_AUTH_TICKET');
    }

    /**
     * 设置路由
     * @return mixed
     */
    public function getRoute()
    {
        return $this->route;
    }

    /**
     * 设置路由
     * @param $route
     * @return mixed
     */
    public function setRoute($route)
    {
        return $this->route = $route;
    }

    /**
     * 处理错误信息
     * @param \Exception $e
     * @return mixed
     */
    public function processException($e)
    {
        throw $e;
    }
}