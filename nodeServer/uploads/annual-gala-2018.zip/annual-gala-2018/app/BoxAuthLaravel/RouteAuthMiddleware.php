<?php
/**
 * 路由中间件[带路径验证]
 *
 * @author: wuzhiqiang
 * @date: 2015年11月18日
 */
namespace App\BoxAuthLaravel;

class RouteAuthMiddleware
{

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, \Closure $next)
    {

        $boxAuth = new BoxAuth();
        if ($request->path() === 'auth/ticket') {
            $ticket = isset($_GET['ticket']) ? trim($_GET['ticket']) : '';
            if ($ticket) {
                try {
                    $boxAuth->setTicket($ticket);
                    Box::checkAuth($boxAuth, $request);
                } catch (AuthException $e) {
                    if ($e->getCode() == 10006) {
                        $url = $boxAuth->getAuthUrl();
                        return redirect($url);
                    }
                }
                return $next($request);
            } else {
                return $next($request);
            }
        }

        $boxAuth->setRoute('/' . $request->path());
        try {
            if (!Box::checkAuth($boxAuth, $request)) {
                $url = $boxAuth->getAuthUrl();
                if ($request->ajax() || $request->wantsJson()) {
                    $data = array(
                        'code' => 401,
                        'message' => '用户未登录，请登录。',
                        'data' => [
                            'url' => $boxAuth->getAuthUrl(),
                            'refererUrl' => $boxAuth->getAuthUrl($request->header('referer')),
                            'domainUrl' => $boxAuth->getAuthUrl($request->getSchemeAndHttpHost())
                        ]
                    );
                    return response()->json($data);
                } else {
                    return redirect($url);
                }
            }
        } catch (AuthException $e) {
            if ($request->ajax()) {
                $data = array(
                    'code' => $e->getCode(),
                    'message' => $e->getMessage(),
                    'data' => []
                );
                return response()->json($data);
            } else {
                if ($e->getCode() == 10006) {
                    $url = $boxAuth->getAuthUrl();
                    return redirect($url);
                }
                exit($e->getMessage());
            }
        }
        return $next($request);
    }
}
