<?php

return [
    'appid' => env('BOX_ID', 0), // 创建应用后可获取
    'appkey' => env('BOX_KEY', ''), // 创建应用后可获取
    'server' => env('AUTH_SERVER', 'http://box.imeete.com/'), // 权限验证地址，内网测试地址为http://test.box.imeete.com/
    'callback_url' => isset($_SERVER['QUERY_STRING']) ? '/admin/?' . $_SERVER['QUERY_STRING'] : '', //登录回跳地址,不填直接调回来源地址

    'timeout' => 1000, // 超时时间ms
    'header' => [
        'guide:color' => '#fff', // 字体颜色
        'app-header:background-color' => '#f39c12', //head背景
        'guide:border-color' => '#fff', // 左上角，向下箭头中的父级span的border颜色
        'platform:border-bottom-color' => '#C57C08', /*平台切换border-bottom-color*/
        'app-name:min-width' => '154px', // 应用名称宽度
        'show:area-scopes' => 0, // 是否显示平台作用域,当应用作用域不为空是有效
        'show:app-scopes' => 1
    ],
    'menu' => [
        'name' => '项目名称',

        // 菜单，ops为该菜单下的
        'menu' => [
        ],
    ],
];