<?php
/**
 * 验证客户端
 *
 * @logs:
 *     修复ticket不存在还发送请求的问题
 *     修复CURL版本低导致常量不存在的问题
 *     添加登录验证API（请将超时时间调到3000以上）
 */

namespace App\BoxAuthLaravel;

class BoxAuthClient
{
    /** @var string 服务地址 */
    public $server = 'http://box.imeete.com/';

    /** @var int 请求超时时间 */
    public $timeout = 1000;

    /** @var string 应用密钥 */
    public $appKey;

    /** @var int 应用ID */
    public $appId;

    protected $api = [];

    public function __get($name)
    {
        if ($name === 'auth') {
            $this->api = [$name];
        }
        return $this;
    }

    protected function reset()
    {
        $this->api = [];
    }

    protected function getSign($query)
    {
        ksort($query);
        foreach ($query as &$v) {
            if ($v === null)
                $v = '';
        }
        unset($v);
        $query = http_build_query($query);
        //注意有urlencode
        return md5($query . '_' . floor(time() / 500) . '_' . $this->appKey);
    }

    public function authRoute($params)
    {
        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'api/auth/route';
        $url .= '?' . http_build_query($params);

        if (!isset($params['ticket']) || empty($params['ticket'])) {
            throw new AuthException('Ticket 为空.', AuthException::TICKET_NOT_FOUND);
        }

        return $this->request($url);
    }

    public function authInfo($params)
    {
        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'api/auth/info';
        $url .= '?' . http_build_query($params);

        if (!isset($params['ticket']) || empty($params['ticket'])) {
            throw new AuthException('Ticket 为空.', AuthException::TICKET_NOT_FOUND);
        }

        return $this->request($url);
    }

    public function authType($params)
    {
        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'api/auth/type';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }

    public function authSendSMS($params)
    {
        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'api/auth/sendSMS';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }

    /**
     * 获取box中所有部门列表
     * @param $params
     * @return mixed
     */
    public function authDepList($params)
    {

        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'boxApi/deptList';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }


    /**
     * 搜索用户列表
     *
     * @param $params key：搜索关键字,type：0全部 1 公司用户，2非公司用户 默认为1
     * @return mixed
     */
    public function authUser($params)
    {

        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'boxApi/user';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }

    /**
     * 搜索部门列表
     *
     * @param $params key：搜索关键字,type：0全部 1 公司用户，2非公司用户 默认为1
     * @return mixed
     */
    public function authDept($params)
    {

        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'boxApi/dept';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }

    public function authLogin($params)
    {

        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'api/auth/login';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }

    public function authLogout($params)
    {

        $params['appid'] = $this->appId;
        $sign = $this->getSign($params);
        $params['sign'] = $sign;

        $url = $this->server . 'api/auth/logout';
        $url .= '?' . http_build_query($params);

        return $this->request($url);
    }

    /**
     * 发送请求
     *
     * @param $url
     * @return mixed
     * @throws AuthException
     */
    public function request($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if (defined('CURLOPT_TIMEOUT_MS') && defined('CURLOPT_CONNECTTIMEOUT_MS')) {
            curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT_MS, $this->timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, $this->timeout);
        } else {
            curl_setopt($ch, CURLOPT_TIMEOUT, intval($this->timeout / 1000) ? intval($this->timeout / 1000) : 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, intval($this->timeout / 1000) ? intval($this->timeout / 1000) : 1);
        }

        $response = curl_exec($ch);
        $errorCode = curl_errno($ch);
        $errorMessage = curl_error($ch);
        curl_close($ch);

        if ($response === false && $errorCode === 28) {
            AuthException::throwException(AuthException::REQUEST_TIMED_OUT);
        } else if ($response === false) {
            throw new AuthException("请求鉴权服务失败:" . $errorMessage, AuthException::UNDEFINED_ERROR);
        } else {
            $data = json_decode($response, 1);

            if ($data === null) {
                AuthException::throwException(AuthException::INCORRECT_JSON_PACKET);
            }

            if ($data['code'] === 0) {
                return $data['data'];
            } else {
                throw new AuthException($data['message'], $data['code']);
            }
        }
    }


    public function __call($name, $params)
    {

        $api = $this->api;
        $this->reset();
        $params = $params[0];

        if (!is_array($params)) {
            throw new \InvalidArgumentException();
        }

        if (trim($this->server) === '') {
            throw new AuthException('server 为空.', AuthException::PARAMETER_MISS);
        }

        if (intval($this->appId) === 0) {
            throw new AuthException('appId 为空.', AuthException::PARAMETER_MISS);
        }

        if (trim($this->appKey) === 0) {
            throw new AuthException('appKey 为空.', AuthException::PARAMETER_MISS);
        }

        $api[0] = lcfirst($api[0]);
        $api[] = ucfirst($name);

        $method = implode('', $api);

        if (!method_exists($this, $method)) {
            throw new AuthException("无法调用的API。", AuthException::UNDEFINED_ERROR);
        }

        return $this->{$method}($params);
    }
}