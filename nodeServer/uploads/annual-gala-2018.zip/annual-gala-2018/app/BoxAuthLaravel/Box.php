<?php
/**
 * Created by PhpStorm.
 * User: wangchao02
 * Date: 2017/11/27
 * Time: 17:21
 */

namespace App\BoxAuthLaravel;

use Illuminate\Http\Request;

class Box
{
    /**
     * @var box用户信息
     */
    public static $boxUser;

    /**
     * 接口验证
     * @param $boxAuth
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|string
     */
    public static function checkAuth(BoxAuth $boxAuth, $request)
    {
        // 判断用户登录以及权限,失败会抛异常
        $boxAuth->auth();
        $user['privileges'] = $boxAuth->getPrivileges();
        $user['user'] = $boxAuth->getUser();
        self::$boxUser = new RemoteUser($user);
        return true;
    }

    /**
     * 专门验证 'auth/ticket'
     * @param $boxAuth
     * @return bool|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public static function authTicket()
    {
        $request = Request::class;
        $boxAuth = new BoxAuth();
        $ticket = isset($_GET['ticket']) ? trim($_GET['ticket']) : '';
        $url = $boxAuth->getAuthUrl();
        if ($ticket) {
            $boxAuth->setTicket($ticket);
            $boxAuth->setRoute('');
            self::checkAuth($boxAuth, $request);
        } else {
            return redirect($url);
        }
    }

    public static function Header()
    {
        $request = Request::class;
        $boxAuth = new BoxAuth();
        $boxAuth->setRoute('/');
        self::checkAuth($boxAuth, $request);
        $user = self::$boxUser;
        $privileges = $user->privileges;
        $scopeKey = $user->currentScope;
        $scopeValue = $user->currentScopeName;
        $scopeList = $privileges['scopes'];
        $server = rtrim(config('box.server'), '/');
        $appId = config('box.appid');
        $header = config('box.header');

        $html = <<<HTML
        <script>
            var scopes = {$scopeList};
            if (scopes && {$header['show:app-scopes']}) {
                window.oPageConfigSpecial = {
                    headSpecial:{
                        show: {$header['show:area-scopes']},
                        specialData: {
                            main:{
                                nowSelect:"{$scopeValue}[{$scopeKey}]",
                                mainList:scopes
                            },
                            specialF:function(data){
                                document.cookie = "box_scope="+decodeURI(data)+"; expires=; path=/";
                                window.location.reload();
                            }
                        }
                    }
                }
            }
        </script>
        <div>
        <script type="text/javascript" src="{$server}/j/head.js?appid={$appId}" id="11a3e4a8b2f209a1"></script>
        </div>
        <style>
            .bb3e364fe4e682a6platform-down-Special,
            .bb3e364fe4e682a6selected-platform-Special,
            .bb3e364fe4e682a6app-fa,
            .bb3e364fe4e682a6appName,
            .bb3e364fe4e682a6user-name,
            .bb3e364fe4e682a6platform-Control,
            .bb3e364fe4e682a6platform-down,
            .bb3e364fe4e682a6guide i{
                color: {$header['guide:color']}!important; /*字体颜色*/
            }
            .bb3e364fe4e682a6app-header{
                background-color: {$header['app-header:background-color']}!important; /*head背景*/
            }
            .bb3e364fe4e682a6guide{
                border-color: {$header['guide:border-color']}!important; /*左上角，向下箭头中的父级span的border颜色*/
            }
            .bb3e364fe4e682a6platformSpecial,
            .bb3e364fe4e682a6platform{
                border-bottom-color: {$header['platform:border-bottom-color']}!important; /*平台切换border-bottom-color*/
            }
            .bb3e364fe4e682a6appName{min-width:{$header['app-name:min-width']};} /*应用名称宽度*/
        </style>
HTML;
        return $html;
    }
}