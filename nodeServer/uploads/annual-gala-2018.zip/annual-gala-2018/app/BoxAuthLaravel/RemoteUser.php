<?php

namespace App\BoxAuthLaravel;

class RemoteUser implements \ArrayAccess
{

    private $attributes;
    public function __construct($attributes)
    {
        $this->attributes = $attributes;
    }

    public function __get($key)
    {
        if($key == 'currentScope' || $key == 'currentScopeName' ){
            $this->getScope();
        }
        return $this->attributes[$key];
    }

    public function privileges()
    {
        if (!isset($this->privileges)) {
            return [];
        }
        return $this->privileges;
    }

    public function offsetExists($offset)
    {
        if($offset == 'currentScope' || $offset == 'currentScopeName' ){
            $this->getScope();
        }
        return isset($this->attributes[$offset]);
    }


    public function offsetGet($offset)
    {
        if($offset == 'currentScope' || $offset == 'currentScopeName' ){
            $this->getScope();
        }
        return $this->attributes[$offset];
    }


    public function offsetSet($offset, $value)
    {
        $this->attributes[$offset] = $value;
    }

    public function offsetUnset($offset)
    {
        return false;
    }

    private function getScope(){

        $this->attributes['currentScope'] = '';
        $this->attributes['currentScopeName'] = '';

        $scopes = isset($this->privileges['scopes']) ? json_decode($this->privileges['scopes'], true) : [];
        if (!empty($scopes)) {
            if (isset($_COOKIE['box_scope']) && in_array($_COOKIE['box_scope'], array_keys($scopes))) {
                $this->attributes['currentScope'] = $_COOKIE['box_scope'];
                $this->attributes['currentScopeName'] = $scopes[$this->attributes['currentScope']];
            } else {
                $this->attributes['currentScope'] = array_keys($scopes)[0];
                $this->attributes['currentScopeName'] = $scopes[$this->attributes['currentScope']];
            }
        }

        return true;

    }
}
