<?php
/**
 * box验证服务提供者
 *
 * User: wangchao02
 * Email: wangchao02@bianfeng.com
 * created: 2016-12-9 09:57
 */

namespace App\BoxAuthLaravel;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class BoxServiceProvider extends ServiceProvider
{
    public function boot()
    {

        // 不带路由验证中间件
        Route::middlewareGroup('auth.only', [\App\BoxAuthLaravel\AuthMiddleware::class]);

        // 带路由验证中间件
        Route::middlewareGroup('auth', [\App\BoxAuthLaravel\RouteAuthMiddleware::class]);

        Route::get('_menu', function () {
            return response()->json(config('box.menu'), 200, [], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        });
        Route::get('/auth/logout', function () {
            $boxAuth = new BoxAuthClient();
            $boxAuth->authClient->auth->logout();
            return redirect(config('box.server') . '/auth/logout');
        });

        class_alias(Box::class, 'Box');
        Blade::directive('BoxHeader', function($expression) {
            return "<?php echo Box::Header{$expression}; ?>";
        });
    }

    public function register()
    {

    }
}