### 新box接入SDK2.0

#### 更新内容说明

```
1.简化SDK接入步骤,争取支持5.1及以上laravel 框架接入box
2.新增boxApi/deptList,boxApi/user,boxApi/dept 接口。
```

#### 接入指南

##### 1.在app目录下新建BoxAuthLaravel，将BoxAuthLaravel文件夹下内如复制进去

##### 2.env 中添加配置

```
BOX_HOST=test.box.imeete.com
BOX_ID=
BOX_KEY=
AUTH_SERVER=http://test.box.imeete.com/
```

##### 3. 在 config/app.php 中 providers 末尾添加

```
App\BoxAuthLaravel\BoxServiceProvider::class
删除之前的： App\Box\AuthServiceProvider::class
```

##### 4.在 routes.php 添加:

```
Route::group(['middleware' => 'auth.only'], function() {
    Route::get('/auth/ticket', function(){
        //授权成功之后需要跳转到何处
        if(isset($_GET['redirect'])) {
            $info = parse_url($_GET['redirect']);
            $path = isset($info['path']) ? $info['path'] : '/';
            $query = isset($info['query']) ? '?' . $info['query'] : '';
            return redirect($path . $query);
        } else {
            return redirect('/');
        }
    });
});
```

##### 5.在 config/box.php 中:

```
    'appid'   => env('BOX_ID', ''), // 创建应用后可获取
    'appkey'  => env('BOX_KEY', ''), // 创建应用后可获取
```

#### 使用方法和旧版相同，路由中使用中间件

```
    'middleware' => 'auth.only' //验证权限不验证路由
    'middleware' => 'auth' //验证权限和路由
```

获取用户

```
必须在使用之前验证成功，然后通过下面方法获得用户信息
Box:$boxUser->user;
Box:$boxUser->privileges;
```