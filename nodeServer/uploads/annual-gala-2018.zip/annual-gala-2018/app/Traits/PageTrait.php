<?php
/**
 * PageTrait.php
 * User: wanghui03
 * Date: 2018/1/24
 * Time: 9:36
 */

namespace App\Traits;

trait PageTrait
{
    /**
     * 页码
     *
     * @var null
     */
    public $page = null;

    /**
     * 每页展示数量
     *
     * @var int
     */
    public $per  = 15;

    /**
     * 是否需要分页
     *
     * @return bool
     */
    public function needPagination(): bool
    {
        return is_int($this->page) && is_int($this->per) && $this->page > 0 && $this->per > 0;
    }

    /**
     * 分页格式组装
     *
     * @param $total
     * @param $list
     * @return array
     */
    public function packPagination(int $total, $list): array
    {
        return [
            'list'  => $list,
            'opage' => [
                'curpage' => $this->page,
                'pcount'  => intval(ceil($total / $this->per)),
                'rcount'  => $total
            ]
        ];
    }

    /**
     * 分页偏移量
     *
     * @return int
     */
    public function offset(): int
    {
        return $this->per * ($this->page - 1);
    }
}