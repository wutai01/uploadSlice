<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Predis\Client;

class SendRedPackTimer extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send_redpack';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'leader send redpack';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        // 每分钟推送队列里的红包口令
        if ($redis->llen('annual:redpack_queue') == 0 || $redis->get('annual:screen_status')) {
            return;
        }
        $redpack = $redis->lpop('annual:redpack_queue');

        // 确保屏幕与服务端连接
        if ($redis->get('annual:connection_num') <= 0) {
            app('log')->error("与大屏幕连接异常，请稍后尝试");
            return;
        }

        // 占用大屏幕
        $redis->setex('annual:screen_status', 20, 1);

        $num = $redis->publish('annual.redpack', $redpack);

        if ($num <= 0) {
            app('log')->error("红包消息推送失败--" . $redpack);
            return;
        }

        return;
    }
}
