<?php
/**
 * BoxApi.php
 *
 * @file: BoxApi.php
 * @author: huguoqiang
 * @email: huguoqiang@bianfeng.com
 * @created: 2016/10/17 9:38
 * @logs:
 */

namespace App\Utils;

use App\Exceptions\BoxException;

class BoxApi
{
    const ROUTE_AUTH_LOGIN          = '/api/auth/login';
    const ROUTE_AUTH_VERIFY         = '/api/auth/verify';
    const ROUTE_AUTH_INFO           = '/api/auth/info';
    const ROUTE_AUTH_ROUTE          = '/api/auth/route';
    const ROUTE_AUTH_TYPE           = '/api/auth/type';
    const ROUTE_AUTH_LOGOUT         = '/api/auth/logout';
    const ROUTE_AUTH_SEND_SMS       = '/api/auth/sendSMS';
    const ROUTE_GET_SCOPES          = '/api/get/scopes';
    const ROUTE_ROLE_USERS          = '/api/role/users';
    const ROUTE_SCOPES_USERS        = '/api/scope/users';
    const ROUTE_SEARCH_USERS        = '/boxApi/user';

    /**
     * 自身单例
     *
     * @var null|self
     */
    protected static $instance = null;

    /**
     * box服务器地址
     *
     * @var string
     */
    protected $server = '';

    /**
     * 请求超时限制
     *
     * @var int
     */
    protected $timeout = 1000;

    /**
     * 主应用id
     *
     * @var int
     */
    protected $tappId = 0;

    /**
     * 应用id
     *
     * @var int
     */
    protected $appId = 0;

    /**
     * 应用的key
     *
     * @var string
     */
    protected $appKey = '';

    /**
     * 要调用的路由
     *
     * @var string
     */
    protected $route = '';

    /**
     * 需要的参数列表
     *
     * @var array
     */
    protected $params = [];

    /**
     * 获取单例
     *
     * @param string $server
     * @param int $appId
     * @param string $appKey
     * @param int $tappId
     * @return BoxApi|null
     */
    public static function instance($server = '', $appId = 0, $appKey = '', $tappId = 0)
    {
        if (! static::$instance instanceof BoxApi) {
            static::$instance = new static($server, $appId, $appKey, $tappId);
        } else {
            static::$instance->init($server, $appId, $appKey, $tappId);
        }
        return static::$instance;
    }

    /**
     * BoxApi constructor.
     *
     * @param string $server
     * @param int $appId
     * @param string $appKey
     * @param int $tappId
     */
    protected function __construct($server, $appId = 0, $appKey = '', $tappId = 0)
    {
        $this->init($server, $appId, $appKey, $tappId);
    }

    /**
     * 禁止克隆
     */
    private function __clone()
    {

    }

    /**
     * 设置应用信息
     *
     * @param string $server
     * @param int $appId
     * @param string $appKey
     * @return $this
     */
    public function init($server, $appId = 0, $appKey = '', $tappId = 0)
    {
        $this->server = $server;
        $this->appId = $appId;
        $this->appKey = $appKey;
        $this->tappId = $tappId;
        return $this;
    }

    /**
     * 设置路由和参数
     *
     * @param string $route
     * @param array $params
     * @return $this
     */
    public function set($route = '', array $params = [])
    {
        $this->route = $route;
        $this->params = $params;
        return $this;
    }

    /**
     * 调用获取结果
     *
     * @return mixed
     * @throws BoxException
     */
    public function send()
    {
        $url = $this->getUrl($this->params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if(defined('CURLOPT_TIMEOUT_MS') && defined('CURLOPT_CONNECTTIMEOUT_MS')) {
            curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT_MS, $this->timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, $this->timeout);
        } else {
            curl_setopt($ch, CURLOPT_TIMEOUT, intval($this->timeout / 1000) ? intval($this->timeout / 1000) : 1 );
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, intval($this->timeout / 1000) ? intval($this->timeout / 1000) : 1 );
        }

        $response = curl_exec($ch);
        $errorCode = curl_errno($ch);
        $errorMessage = curl_error($ch);
        curl_close($ch);

        if($response === false && $errorCode === 28) {
            BoxException::throwException(BoxException::REQUEST_TIMED_OUT);
        } else if($response === false) {
            throw new BoxException("请求鉴权服务失败:" . $errorMessage, BoxException::UNDEFINED_ERROR);
        } else {
            $data = json_decode($response, 1);

            if($data === null) {
                BoxException::throwException(BoxException::INCORRECT_JSON_PACKET);
            }

            if($data['code'] === 0) {
                return $data['data'];
            } else {
                throw new BoxException($data['message'], $data['code']);
            }
        }
    }

    /**
     * 根据关键词搜索用户
     *
     * @param null|string $keyword
     *
     * @return mixed
     */
    public function searchUsers($keyword = null)
    {
        $this->route = static::ROUTE_SEARCH_USERS;
        $this->params = ['type' => 0, 'key' => strval($keyword)];
        $users = $this->send();
        foreach ($users as $key => $user) {
            $users[$key]['head'] = $this->server . "/avatar/" . md5($user['email']);
        }
        return $users;
    }

    /**
     * 获取拥有某个作用域的用户列表
     *
     * @param null $scope
     * @param null $appId
     *
     * @return mixed
     */
    public function getUsersOfScopes($scope = null, $appId = null)
    {
        $this->route = static::ROUTE_SCOPES_USERS;
        $this->params = ['tappid' => $appId ?: $this->tappId ?: $this->appId];
        if (null !== $scope) {
            $this->params['skey'] = $scope;
        }
        return $this->send();
    }

    /**
     * 获取某关键字对应角色的用户列表
     *
     * @param string $keyword
     * @return mixed
     * @throws BoxException
     */
    public function getUsersOfRole($keyword = '')
    {
        $this->route = static::ROUTE_ROLE_USERS;
        $this->params = ['keyword' => $keyword];
        return $this->send();
    }

    /**
     * 获取某应用的作用域，不传递时则获取自身
     *
     * @param null|integer $appId
     * @return mixed
     * @throws BoxException
     */
    public function getScopes($appId = null)
    {
        $this->route = static::ROUTE_GET_SCOPES;
        $this->params = ['tappid' => $appId ?: $this->appId];
        return $this->send();
    }

    /**
     * 获取签名
     *
     * @param $query
     * @return mixed
     */
    protected function getSign($query)
    {
        ksort($query);
        foreach($query as &$v) {
            if($v === null)
                $v = '';
        }
        unset($v);
        $query = http_build_query($query);
        //注意有urlencode
        return md5($query . '_' . floor(time() / 500) . '_' . $this->appKey);
    }

    /**
     * 获取最终调用地址
     *
     * @param $params
     * @return string
     */
    protected function getUrl($params)
    {
        $params['appid'] = $this->appId;
        $params['sign'] = $this->getSign($params);
        $url = $this->server . $this->route;
        $url .= '?' . http_build_query($params);
        return $url;
    }

    /**
     * 安全令牌验证
     *
     * @param string $email
     * @param string $code
     * @return mixed
     * @throws BoxException
     */
    public function verifyToken($email = '', $code = '')
    {
        $this->route = static::ROUTE_AUTH_VERIFY;
        $this->params = [
            'email' => $email,
            'code'  => $code,
        ];
        return $this->send();
    }
}
