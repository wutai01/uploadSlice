<?php
/**
 * BoxException.php
 * User: wanghui03
 * Date: 2018/1/31
 * Time: 9:58
 */

namespace App\Exceptions;


class BoxException extends \Exception
{

}