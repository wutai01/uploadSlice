<?php
/**
 * WechatController.php
 * User: wanghui03
 * Date: 2018/1/18
 * Time: 10:24
 */

namespace App\Http\Controllers;

use App\Jobs\SendBarrage;
use App\Models\Barrage;
use App\Models\User;
use App\Utils\FilterChinese;
use App\Utils\Http;
use Predis\Client;

class WechatController extends Controller
{
    public function index()
    {
        if (!$this->checkSignature()) {
            echo "fail";
        }
        echo app('request')->get('echostr');
    }

    // 接收微信推送事件
    public function wxMsg()
    {
        $message = file_get_contents('php://input');
        $message = $this->xmlDecode($message);

        // 必须返回格式信息
        $response = [
            'ToUserName'   => $message['FromUserName'],
            'FromUserName' => $message['ToUserName'],
            'CreateTime'   => time(),
        ];

        // 文本消息
        if ('text' === $message['MsgType']) {
            list($msgType, $msg) = $this->dealTextMessage($message['FromUserName'], $message['Content'], $message['MsgId']);
            if ('' == $msg) {
                echo '';
                exit;
            }

            // 必须返回格式信息
            $response['MsgType'] = $msgType;

            // 消息回复
            if ('text' === $msgType) { // 回复文本消息
                $response['Content'] = $msg;
            } else if ('news' === $msgType) { // 回复图文消息
                $response['ArticleCount'] = count($msg);
                $response['Articles']     = $msg;
            }

            echo $this->simpleXmlEncode($response);
            exit;
        } else if ('event' === $message['MsgType']) {
            $responseMsg = '';
            switch ($message['EventKey']) {
                case 'TRAVEL':
                    // 出行安排
                    $response['MediaId'] = 'jJpImaCCvLSGQFrRrW6DXJvBGOfdP_ByGc5hs0zTqTaHgh63zR3spBgPeaN1Egbg';
                    $responseMsg = $this->sendImageMessage($response);
                    break;
                case 'SCHEDULE':
                    // 日程安排
                    $response['MediaId'] = '3lu2-hVHrttyshU4emUi9yJ8t54jhdwp8t6F5VfhqZY5zkv4FBHJ3MEKXF-p526t';
                    $responseMsg = $this->sendImageMessage($response);
                    break;
                default:
                    break;
            }

            echo $responseMsg;
            exit;
        }

        echo "";
    }

    public function dealTextMessage($openid, $content, $msgId)
    {
        // 字数限制
        if (mb_strlen($content) > 30) {
            return ['text', "弹幕消息太长啦 ^_^!"];
        }

        $redisPrefix = app('config')->get('basic.redis_prefix');
        $user = app('redis')->get($redisPrefix . ':users:' . $openid);
        if ($user) {
            $user = json_decode($user, true);
        } else {
            $user = User::where('openid', $openid)->first();
            if (!empty($user)) {
                $user = $user->toArray();
                app('redis')->set($redisPrefix . ':users:' . $openid, json_encode($user));
            }
        }

        // 匹配关键词‘年会’,绑定用户
        if ('年会' == $content) {
            if (!$user) {
                list($ok, $msg) = $this->bindUser($openid);
                if (!$ok) {
                    return ['text', $msg];
                }
            }

            // 推送年会攻略
            $articles = [
                [
                    'Title'       => '年会攻略',
                    'Description' => '年会攻略年会攻略年会攻略',
                    'PicUrl'      => 'http://www.bianfeng.com/usr/themes/bianfeng/i/header-logo.png',
                    'Url'         => 'http://www.bianfeng.com/'
                ],
            ];

            return ['news', $articles];
        } else {
            // 未授权用户不能发送弹幕
            if (!$user || !key_exists('openid', $user)) {
                return ['text', ""];
            }

            // 屏蔽已拉黑的用户
            if ($user['status'] == 1) {
                return ['text', "您已被管理员禁言"];
            }

            // 已绑定微信用户
            list($ok, $errMsg) = $this->sendBarrage($user, $content, $msgId);
            if (false === $ok) {
                return ["text", $errMsg];
            }
            return ['text', ""];
        }
    }

    // 年会人员绑定
    public function bindUser($openid)
    {
        // 获取access_token
        $redisPrefix = app('config')->get('basic.redis_prefix');
        $accessToken = app('redis')->get($redisPrefix . ':access_token');
        if (! $accessToken) {
            $wxResponse = Http::instance()->get("https://api.weixin.qq.com/cgi-bin/token?" . http_build_query([
                    'grant_type' => 'client_credential',
                    'appid'      => app('config')->get('basic.wechat.app_id'),
                    'secret'     => app('config')->get('basic.wechat.app_secret')
                ]))->send();

            $wxResponse = json_decode($wxResponse, true);
            $accessToken = $wxResponse['access_token'];

            // 设置7000s后自动过期
            app('redis')->setex($redisPrefix . ':access_token', 7000, $accessToken);
        }

        $wxUserInfo = Http::instance()->get("https://api.weixin.qq.com/cgi-bin/user/info?" . http_build_query([
                'access_token' => $accessToken,
                'openid'       => $openid,
                'lang'         => 'zh_CN'
            ]))->send();

        $wxUserInfo = json_decode($wxUserInfo, 1);

        // 绑定用户信息
        try {
            $user = [
                'openid'      => $openid,
                'nickname'    => $wxUserInfo['nickname'],
                'headimgurl'  => $wxUserInfo['headimgurl'],
                'role'        => 1,
                'draw_num'    => 0,
                'barrage_num' => 0,
                'status'      => 0
            ];

            $user = User::create($user);

            // 缓存用户信息
            app('redis')->set($redisPrefix . ':users:' . $user->openid, json_encode($user->toArray()));
        } catch (\Exception $e) {
            return [false, '绑定微信失败，请重新尝试'];
        }

        return [true, ''];
    }

    // 发送弹幕
    public function sendBarrage($user, $message, $msgId)
    {
        // 过滤不支持的消息
        if ('【收到不支持的消息类型，暂无法显示】' == $message) {
            return [false, '无法支持该消息类型的弹幕'];
        }

        if (!$barrage = Barrage::where('msgId', $msgId)->first()) {
            // 弹幕消息存储
            $barrage = [
                'msgId'      => $msgId,
                'openid'     => $user['openid'],
                'headimgurl' => $user['headimgurl'],
                'nickname'   => $user['nickname'],
                'content'    => $message,
                'type'       => Barrage::TYPE_NORMAL, // 普通弹幕消息
                'created_at' => date('Y-m-d H:i:s'),
            ];
            try {
                $barrage = Barrage::create($barrage);
            } catch (\Exception $e) {
                return [false, "当前服务器繁忙，休息一下吧"];
            }
        }

        // 用户消息推送至队列
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        $redis->publish('annual.message', json_encode([
            'headimgurl' => $barrage->headimgurl,
            'content' => $barrage->content
        ]));
        return [true, ""];
    }

    protected function xmlDecode($xmlContent)
    {
        //针对xml实体扩展攻击的防御措施
        libxml_disable_entity_loader(true);
        $content = @simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NOCDATA);
        return json_decode(json_encode($content), true);
    }

    protected function simpleXmlEncode($body, $outLabel = 'xml', $needle = true)
    {
        if ($needle) {
            $xml = "<{$outLabel}>";
        } else {
            $xml = '';
        }

        foreach ($body as $key => $val) {
            if (is_numeric($val)) {
                $xml .= "<{$key}>{$val}</{$key}>";
            } else if ('Articles' === $key) { // 图文消息特殊处理
                $xml .= "<Articles>";
                foreach ($val as $pv) {
                    $xml .= "<item>";
                    $xml .= $this->simpleXmlEncode($pv, '', false);
                    $xml .= "</item>";
                }
                $xml .= "</Articles>";
            } else {
                $xml .= "<{$key}><![CDATA[{$val}]]></{$key}>";
            }
        }

        if ($needle) {
            $xml .= "</{$outLabel}>";
        }

        return $xml;
    }

    protected function sendImageMessage($messgae)
    {
        return "<xml>
                <ToUserName><![CDATA[" . $messgae['ToUserName'] . "]]></ToUserName>
                <FromUserName><![CDATA[" . $messgae['FromUserName'] . "]]></FromUserName>
                <CreateTime>" . $messgae['CreateTime'] . "</CreateTime>
                <MsgType><![CDATA[image]]></MsgType>
                <Image>
                <MediaId><![CDATA[" . $messgae['MediaId'] . "]]></MediaId>
                </Image>
                </xml>";
    }

    private function checkSignature()
    {
        $request   = app("request");
        $signature = $request->get("signature");
        $timestamp = $request->get("timestamp");
        $nonce     = $request->get("nonce");
        $token     = 'bianfeng';
        $tmpArr    = [$token, $timestamp, $nonce];
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);
        if ($tmpStr != $signature) {
            return false;
        }
        return true;
    }
}
