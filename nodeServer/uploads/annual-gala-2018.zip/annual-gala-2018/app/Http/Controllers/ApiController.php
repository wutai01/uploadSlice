<?php
/**
 * ApiController.php
 * User: wanghui03
 * Date: 2018/1/18
 * Time: 10:20
 */

namespace App\Http\Controllers;

use App\Models\Barrage;
use App\Models\Prize;
use App\Models\UserPrize;
use App\Traits\PageTrait;
use Illuminate\Support\Facades\DB;
use Predis\Client;

class ApiController extends BaseController
{
    use PageTrait;

    // 奖品列表
    public function getPrizes()
    {
        // 获取奖项信息
        $prizeGiftDic = $this->getPrizeGiftsDic();

        // 数据处理
        $data = [];
        foreach (array_values($prizeGiftDic) as $one) {
            $data['list'][] = [
                'id'     => $one['id'],
                'name'   => $one['name'],
                'pics'   => $one['pics'],
                'status' => $one['status'],
                'gifts'  => array_values($one['gifts'])
            ];
        }

        $redis = app('redis');
        $redisPrefix = app('config')->get('basic.redis_prefix');
        if (! empty($curPrize = $redis->get($redisPrefix. ":current_prize"))) {
            $data['curPrize'] = json_decode($curPrize, 1);
        } else {
            $data['curPrize'] = [
                'pid'    => 0,
                'gid'    => 0,
                'status' => 0
            ];
        }

        return [
            'code'    => 0,
            'message' => 'success',
            'data'    => $data
        ];
    }

    // 奖品列表
    public function prizesOnClient()
    {
        $prizeGiftDic = $this->getPrizeGiftsDic();

        $list = [];
        foreach ($prizeGiftDic as $prize) {
            foreach ($prize['gifts'] as $gift) {
                $list[] = [
                    'pid'    => $prize['id'],
                    'gid'    => $gift['id'],
                    'prize'  => $prize['name'],
                    'gift'   => $gift['status'] == 1 ? $gift['name'] : '未揭晓',
                    'pics'   => $gift['pics'],
                    'status' => $gift['status']
                ];
            }
        }
        return [
            'code'    => 0,
            'message' => 'success',
            'data'    => $list
        ];
    }

    // 奖品信息投屏
    public function inputDrawPrize()
    {
        list($ok, $info) = $this->validPrizeGift($this->request->get('pid'), $this->request->get('gid'));

        // 确保屏幕未被占用
        if (app('redis')->get('annual:screen_status')) {
            return [
                'code'    => 4010,
                'message' => '大屏幕被占用，请稍后尝试~~',
            ];
        }

        if (false === $ok) {
            return [
                'code' => 4001,
                'message' => $info
            ];
        }

        list($prize, $gift) = $info;

        // 奖品状态更新
        try {
            Prize::where('id', $gift->id)->update(['status' => 1]);
            $this->cachePrizeGiftsDic();
        } catch (\Exception $e) {
            app('log')->error('奖品状态变更失败---gift---' . $gift->id);
        }

        // 推送奖品奖项信息
        /**
         * @var Client $redis
         */
        $redis = app('redis');
        $redisPrefix = app('config')->get('basic.redis_prefix');
        $redis->set($redisPrefix . ':current_prize', json_encode([
            'pid' => $prize->id,
            'gid' => $gift->id,
            'status' => 1
        ]));

        // 占用屏幕
        $redis->set('annual:screen_status', 1);

        // 确保屏幕与服务端连接
        if ($redis->get('annual:connection_num') <= 0) {
            return [
                'code' => 5001,
                'message' => '与大屏幕连接异常，请稍后尝试'
            ];
        }

        $pics = explode('|', $gift->pics);
        $prizeNameMap = app('config')->get('basic.prize_name');
        $num = $redis->publish('annual.prize.info', json_encode([
            'prize' => key_exists($prize->name, $prizeNameMap) ? $prizeNameMap[$prize->name] : '',
            'gift'  => $gift->name,
            'pic'   => sizeof($pics) >= 2 ? env('APP_URL') . $pics[1] : ''
        ]));

        if ($num <= 0) {
            return [
                'code' => 5002,
                'message' => '录入失败，请重新尝试'
            ];
        }

        return [
            'code'    => 0,
            'message' => 'success',
            'data'    => '奖品信息录入成功'
        ];
    }

    // 中奖人员录入
    public function inputDrawPrizeUser()
    {
        list($ok, $info) = $this->validPrizeGift($this->request->get('pid'), $this->request->get('gid'));

        if (false === $ok) {
            return [
                'code' => 4001,
                'message' => $info
            ];
        }

        list($prize, $gift) = $info;

        if ($gift->status != 1) {
            return [
                'code' => 4002,
                'message' => '请先【更新奖品信息】'
            ];
        }

        // 获奖名单
        $userNumList = $this->request->get('numList', null);
        if (empty($userNumList)) {
            return [
                'code' => 4004,
                'message' => "请至少输入一个中奖号码"
            ];
        }

        // 奖品中奖名单去重
        $repeatNumbers = UserPrize::whereIn('draw_num', $userNumList)
            ->pluck('draw_num')
            ->toArray();

        if (count($repeatNumbers) > 0) {
            $repeatNumbers = implode(',', $repeatNumbers);
            return [
                'code' => 4005,
                'message' => "中奖号码[{$repeatNumbers}]重复录入"
            ];
        }

        // 保存中奖名单信息
        $data = [];
        $currentDate = date('Y-m-d H:i:s');
        foreach ($userNumList as $one) {
            $data[] = [
                'draw_num'   => $one,
                'prize'      => $prize->id,
                'gift'       => $gift->id,
                'status'     => UserPrize::STATUS_UNGET,
                'created_at' => $currentDate
            ];
        }

        try {
            DB::table('user-prize')->insert($data);
        } catch (\Exception $e) {
            app('log')->error("中奖号码录入失败---" . $e->getMessage());
            return [
                'code' => 5001,
                'message' => "中奖号码录入失败，请重新尝试"
            ];
        }

        // 发布奖品奖项信息
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        // 确保屏幕与服务端连接
        if ($redis->get('annual:connection_num') <= 0) {
            return [
                'code' => 5001,
                'message' => '与大屏幕连接异常，请稍后尝试'
            ];
        }

        $pics = explode('|', $gift->pics);
        $prizeNameMap = app('config')->get('basic.prize_name');
        $num = $redis->publish('annual.prize.result', json_encode([
            'prize'   => key_exists($prize->name, $prizeNameMap) ? $prizeNameMap[$prize->name] : '',
            'gift'    => $gift->name,
            'pic'     => sizeof($pics) >= 2 ? env('APP_URL') . $pics[1] : '',
            'numList' => $userNumList
        ]));

        if ($num <= 0) {
            return [
                'code' => 5002,
                'message' => '录入失败，请重新尝试'
            ];
        }

        return [
            'code'    => 0,
            'message' => 'success',
            'data'    => '中奖号码录入成功'
        ];
    }

    // 奖品信息投屏条件验证
    protected function validPrizeGift($pid, $gid)
    {
        if (!$pid) {
            return [false, "请选择奖项"];
        }
        if (!$gid) {
            return [false, "请选择奖品"];
        }

        $prize = Prize::find($pid);
        if (empty($prize)) {
            return [false, "奖项信息不存在或已被删除"];
        }

        $gift = Prize::find($gid);
        if (!$gift) {
            return [false, "奖品信息不存在或已被删除"];
        }
        if ($gift->pid != $pid) {
            return [false, "奖品[{$gift->name}]不属于奖项[{$prize->name}]"];
        }

        return [true, [$prize, $gift]];
    }

    // 查询中奖信息
    public function lottetyRecords()
    {
        $model = new UserPrize();

        // 奖项过滤
        if ($pid = $this->request->get('pid')) {
            $model = $model->where('prize', $pid);
        }

        // 奖品过滤
        if ($gid = $this->request->get('gift')) {
            $model = $model->where('gift', $gid);
        }

        // 领取状态过滤
        $status = $this->request->get('status');
        if ($status !== null && in_array($status, [0, 1])) {
            $model = $model->where('status', $status);
        }

        // 中奖号码查询
        if ($num = $this->request->get('num')) {
            $model = $model->where('draw_num', $num);
        }

        // 分页获取中奖记录
        $this->page = intval($this->request->get('page'));
        if ($this->needPagination()) {
            // 总记录数
            $total = $model->count();

            $userPrizeRecords = $model->orderBy('created_at', 'desc')
                ->offset($this->offset())
                ->limit($this->per)
                ->get(['draw_num', 'prize', 'gift', 'created_at'])
                ->toArray();
            $list = $this->mergePrize($userPrizeRecords);

            return [
                'code'    => 0,
                'message' => 'success',
                'data'    => $this->packPagination($total, $list)
            ];
        }

        $userPrizeRecords = $model->get(['draw_num', 'prize', 'gift', 'created_at'])->toArray();
        $list = $this->mergePrize($userPrizeRecords);

        return [
            'code'    => 0,
            'message' => 'success',
            'data'    => $list
        ];
    }

    // 奖项信息
    protected function mergePrize($userPrizeRecords)
    {
        $prizeGiftDic = $this->getPrizeGiftsDic();

        foreach ($userPrizeRecords as $k => $record) {
            if (key_exists($record['prize'], $prizeGiftDic)) {
                $curPrize = $prizeGiftDic[$record['prize']];
                $userPrizeRecords[$k]['prize'] = $curPrize['name'];
                $userPrizeRecords[$k]['gift']  = key_exists($record['gift'], $curPrize['gifts'])
                    ? $curPrize['gifts'][$record['gift']]['name'] : '--';
                $userPrizeRecords[$k]['pics']  = key_exists($record['gift'], $curPrize['gifts'])
                    ? $curPrize['gifts'][$record['gift']]['pics'] : '--';
            } else {
                $userPrizeRecords[$k]['prize'] = '--';
                $userPrizeRecords[$k]['gift']  = '--';
                $userPrizeRecords[$k]['pics']  = '--';
            }
        }
        return $userPrizeRecords;
    }

    // 边锋大大发红包
    public function sendRedPackage()
    {
        $leader = $this->request->get('leader');
        $token = $this->request->get('token');

        if (!$leader) {
            return [
                'code'    => 4001,
                'message' => '请输入领导信息'
            ];
        }

        if (!$token) {
            return [
                'code'    => 4002,
                'message' => '请输入红包口令'
            ];
        }

        $data = [
            'openid'          => '',
            'headimgurl'      => '',
            'content'         => $token,
            'nickname'        => $leader,
            'type'            => Barrage::TYPE_REDPACK,
            'created_at'      => date('Y-m-d H:i:s')
        ];

        try {
            Barrage::create($data);
        } catch (\Exception $e) {
            return [
                'code'    => 5001,
                'message' => '发红包出了点意外，请重新尝试'
            ];
        }

        /**
         * @var Client $redis
         */
        $redis = app('redis');
        $redisPrefix = app('config')->get('basic.redis_prefix');

        // 大屏幕占用状态
        $status = $redis->get('annual:screen_status');
        $queueLength = $redis->llen('annual:redpack_queue');

        // 抽奖、有红包正在发的情况，将后续领导发送的红包替换放入队列
        if ($status || $queueLength > 0) {
            $redis->rpush($redisPrefix . ':redpack_queue', json_encode([
                'leader' => $leader,
                'token'  => $token
            ]));
            $num = $queueLength > 0 ? $queueLength : 1;
            return [
                'code'    => 4003,
                'message' => "红包发送成功，前面还有{$num}位大大正在排队~~"
            ];
        }

        // 确保屏幕与服务端连接
        if ($redis->get('annual:connection_num') <= 0) {
            return [
                'code' => 5001,
                'message' => '与大屏幕连接异常，请稍后尝试'
            ];
        }

        $num = $redis->publish('annual.redpack', json_encode([
            'leader' => $leader,
            'token'  => $token
        ]));

        // 发红包占用屏幕
        $redis->setex('annual:screen_status', 60, 1);

        if ($num <= 0) {
            return [
                'code' => 5002,
                'message' => '红包发送异常，请重新尝试'
            ];
        }

        return [
            'code'    => 0,
            'message' => 'success',
            'data'    => '红包已经成功发出了'
        ];
    }

    // 结束抽奖
    public function endPrize()
    {
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        // 确保屏幕与服务端连接
        if ($redis->get('annual:connection_num') <= 0) {
            return [
                'code' => 5001,
                'message' => '与大屏幕连接异常，请稍后尝试'
            ];
        }

        $redisPrefix = app('config')->get('basic.redis_prefix');

        // 结束抽奖
        $redis->set($redisPrefix . ':current_prize', json_encode([
            'pid'    => 0,
            'gid'    => 0,
            'status' => 0
        ]));

        // 释放屏幕
        $redis->set('annual:screen_status', 0);

        $num = $redis->publish('annual.prize.end', $redis->get($redisPrefix . ':current_prize'));
        if ($num <= 0) {
            return [
                'code' => 5002,
                'message' => '无法正常结束，请重新尝试'
            ];
        }

        return [
            'code' => 0,
            'message' => 'success'
        ];
    }

    public function switchScreen()
    {
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        // 确保屏幕与服务端连接
        if ($redis->get('annual:connection_num') <= 0) {
            return [
                'code' => 5001,
                'message' => '与大屏幕连接异常，请稍后尝试'
            ];
        }

        // 释放屏幕
        $redis->set('annual:screen_status', 0);

        $num = $redis->publish('annual.screen.switch', 1);
        if ($num <= 0) {
            return [
                'code' => 5002,
                'message' => '无法切换，请重新尝试'
            ];
        }

        return [
            'code' => 0,
            'message' => 'success'
        ];
    }
}
