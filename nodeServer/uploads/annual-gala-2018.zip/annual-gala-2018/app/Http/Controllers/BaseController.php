<?php
/**
 * BaseController.php
 * User: wanghui03
 * Date: 2018/1/21
 * Time: 9:52
 */

namespace App\Http\Controllers;

use App\Models\Prize;
use Illuminate\Http\Request;
use Predis\Client;

class BaseController extends Controller
{
    public $request;

    public function __construct()
    {
        /**
         * @var Request $request
         */
        $this->request = app('request');
    }

    // 奖项奖品字典
    public function getPrizeGiftsDic()
    {
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        $redisPrefix = app('config')->get('basic.redis_prefix');

        if ($redis->exists($redisPrefix . ":prizes")) {
            return json_decode($redis->get($redisPrefix . ":prizes"), 1);
        }

        return $this->cachePrizeGiftsDic();
    }

    // 构建奖项字典
    public function cachePrizeGiftsDic()
    {
        /**
         * @var Client $redis
         */
        $redis = app('redis');

        $redisPrefix = app('config')->get('basic.redis_prefix');

        // 获取奖项信息
        $prizeItems = Prize::where('pid', 0)->orderBy('order', 'desc')->get();

        // 获取奖项下的奖品列表
        $data = [];
        foreach ($prizeItems as $one) {
            $gifts = Prize::where('pid', $one['id'])->orderBy('order', 'desc')->get();

            $temp = [];
            foreach ($gifts as $item) {
                $temp[$item['id']] = [
                    'id'     => $item['id'],
                    'name'   => $item['name'],
                    'pics'    => $item['pics'],
                    'status' => $item['status'],
                ];
            }
            $data[$one['id']] = [
                'id'     => $one['id'],
                'name'   => $one['name'],
                'pics'    => $one['pics'],
                'status' => $one['status'],
                'gifts'  => $temp
            ];
        }

        $redis->set($redisPrefix . ":prizes", json_encode($data));
        return $data;
    }
}
