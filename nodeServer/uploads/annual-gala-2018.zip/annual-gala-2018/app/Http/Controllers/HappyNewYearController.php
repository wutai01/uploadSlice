<?php
/**
 * HappyNewYear.php
 * User: wanghui03
 * Date: 2018/1/19
 * Time: 16:37
 */

namespace App\Http\Controllers;

use App\Models\Prize;
use App\Models\User;
use App\Models\UserPrize;
use Illuminate\Support\Facades\DB;

class HappyNewYearController extends BaseController
{
    public function index()
    {
        return view('pc.index');
    }

    public function redpack()
    {
        return view('mobile.sendRedpack');
    }

    public function screen()
    {
        return view('screen.index');
    }

    public function prizes()
    {
        $list = [];
        $prizeGiftDic = $this->getPrizeGiftsDic();

        // 中奖号码查询
        $num = $this->request->get('num');
        if ($num) {
            $log = UserPrize::where('draw_num', $num)->get(['prize', 'gift'])->toArray();
            if (!empty($log)) {
                $myPrizeGift = array_column($log, 'gift', 'prize');
                foreach ($prizeGiftDic as $pid => $prize) {
                    if (!in_array($pid, array_keys($myPrizeGift))) {
                        continue;
                    }
                    foreach ($prize['gifts'] as $gid => $gift) {
                        if ($gid != $myPrizeGift[$pid]) {
                            continue;
                        }
                        $list[] = [
                            'pid'    => $prize['id'],
                            'gid'    => $gift['id'],
                            'prize'  => $prize['name'],
                            'gift'   => $gift['status'] == 1 ? $gift['name'] : '未揭晓',
                            'pic'    => current(explode('|', $gift['pics'])),
                            'status' => $gift['status']
                        ];
                    }
                }
            }
        } else {
            foreach ($prizeGiftDic as $prize) {
                foreach ($prize['gifts'] as $gift) {
                    $list[] = [
                        'pid'    => $prize['id'],
                        'gid'    => $gift['id'],
                        'prize'  => $prize['name'],
                        'gift'   => $gift['status'] == 1 ? $gift['name'] : '未揭晓',
                        'pic'    => current(explode('|', $gift['pics'])),
                        'status' => $gift['status']
                    ];
                }
            }
        }

        return view('mobile.prize')->with(['list' => $list]);
    }

    // 奖项中奖用户列表
    public function prizeUsers()
    {
        $info = [];

        $gid = $this->request->get('gift');
        if (!$gid) {
            exit("请选择一个奖项");
        }

        $gift = Prize::find($gid);
        $info['gift'] = [
            'prize_name' => Prize::where('id', $gift->pid)->value('name'),
            'gift_name' => $gift->name,
            'pic' => current(explode('|', $gift->pics)),
        ];
        $info['numList'] = UserPrize::where('gift', $gid)->pluck('draw_num')->toArray();

        return view('mobile.prizeUsers')->with(['info' => $info]);
    }

    public function syscPrize()
    {
        $prizes = app('config')->get('basic.prizes');
        foreach ($prizes as $one) {
            $data = [
                'name'   => $one['name'],
                'pics'   => $one['pics'],
                'status' => 0,
                'pid'    => 0,
                'order'  => $one['order'],
            ];
            $prize = Prize::create($data);

            // 礼品信息
            $data = [];
            foreach ($one['gifts'] as $item) {
                $data[] = [
                    'name'   => $item['name'],
                    'pics'   => $item['pics'],
                    'status' => 0,
                    'pid'    => $prize->id,
                    'order'  => $one['order'] ?? 1
                ];
            }
            DB::table('prizes')->insert($data);
        }
        return ['code' => 0, 'message' => 'success'];
    }

    // [取消]拉黑用户信息
    public function changeUserStatus(string $openid)
    {
        $user = User::where('openid', $openid)->first();
        if (!$user) {
            return [
                'code' => 4000,
                'message' => '用户不存在'
            ];
        }

        $status = 1 - $user->status;

        $res = User::where('openid', $openid)->update(['status' => $status]);
        if (!$res) {
            return [
                'code' => 4001,
                'message' => $status ? '拉入黑名单失败' : '拉入白名单失败'
            ];
        }

        $redisPrefix = app('config')->get('basic.redis_prefix');
        $user->status = $status;
        app('redis')->set($redisPrefix . ":users:".$openid, json_encode($user->toArray()));

        return [
            'code' => 0,
            'message' => 'success',
            'data' => null
        ];
    }
}
