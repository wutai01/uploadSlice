<?php

namespace App\Providers;

use App\Utils\BoxApi;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        // Box
        $this->app->singleton('box_api', function () {
            return BoxApi::instance(rtrim(env('AUTH_SERVER'), '/'), env('BOX_ID'), env('BOX_KEY'), env('BOX_TID'));
        });
    }
}
